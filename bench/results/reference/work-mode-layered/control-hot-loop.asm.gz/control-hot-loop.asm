000000000000733e <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>:
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
    733e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    7343:	e8 08 0a 01 00       	call   17d50 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()>
std::allocator<char>::~allocator():
/usr/include/c++/13/bits/allocator.h:184
    7348:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    734d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7354:	00 00 
    7356:	75 08                	jne    7360 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]+0x22>
    7358:	48 89 df             	mov    %rbx,%rdi
    735b:	e8 60 fb ff ff       	call   6ec0 <_Unwind_Resume@plt>
    7360:	e8 6b f8 ff ff       	call   6bd0 <__stack_chk_fail@plt>


0000000000007600 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]>:
std::_Function_base::~_Function_base():
/usr/include/c++/13/bits/std_function.h:243
    7600:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    7605:	48 85 c0             	test   %rax,%rax
    7608:	74 26                	je     7630 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x30>
/usr/include/c++/13/bits/std_function.h:244
    760a:	48 89 e7             	mov    %rsp,%rdi
    760d:	ba 03 00 00 00       	mov    $0x3,%edx
    7612:	48 89 fe             	mov    %rdi,%rsi
    7615:	ff d0                	call   *%rax
/usr/include/c++/13/bits/shared_ptr_base.h:1068
    7617:	eb 17                	jmp    7630 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x30>
/usr/include/c++/13/bits/std_function.h:243
    7619:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    761e:	48 85 c0             	test   %rax,%rax
    7621:	74 0d                	je     7630 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x30>
/usr/include/c++/13/bits/std_function.h:244
    7623:	48 89 e7             	mov    %rsp,%rdi
    7626:	ba 03 00 00 00       	mov    $0x3,%edx
    762b:	48 89 fe             	mov    %rdi,%rsi
    762e:	ff d0                	call   *%rax
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::~__shared_count():
/usr/include/c++/13/bits/shared_ptr_base.h:1071
    7630:	48 89 ef             	mov    %rbp,%rdi
    7633:	e8 28 04 01 00       	call   17a60 <std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release()>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]:
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:91
    7638:	48 89 df             	mov    %rbx,%rdi
prepare<(anonymous namespace)::Ecs<1> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:91
    763b:	e8 a0 05 01 00       	call   17be0 <bench::harness::Prepared::~Prepared()>
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::~__shared_count():
/usr/include/c++/13/bits/shared_ptr_base.h:1071
    7640:	48 89 ef             	mov    %rbp,%rdi
    7643:	e8 18 04 01 00       	call   17a60 <std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release()>
    7648:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    764d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7654:	00 00 
    7656:	75 2d                	jne    7685 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x85>
    7658:	4c 89 e7             	mov    %r12,%rdi
    765b:	e8 60 f8 ff ff       	call   6ec0 <_Unwind_Resume@plt>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]:
/usr/include/c++/13/bits/new_allocator.h:172
    7660:	be 68 15 00 00       	mov    $0x1568,%esi
deallocate():
/usr/include/c++/13/bits/new_allocator.h:172
    7665:	48 89 ef             	mov    %rbp,%rdi
    7668:	e8 03 f5 ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
    766d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7672:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7679:	00 00 
    767b:	75 0d                	jne    768a <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x8a>
    767d:	48 89 df             	mov    %rbx,%rdi
    7680:	e8 3b f8 ff ff       	call   6ec0 <_Unwind_Resume@plt>
    7685:	e8 46 f5 ff ff       	call   6bd0 <__stack_chk_fail@plt>
    768a:	e8 41 f5 ff ff       	call   6bd0 <__stack_chk_fail@plt>


000000000000b100 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
    b100:	f3 0f 1e fa          	endbr64
    b104:	41 57                	push   %r15
    b106:	41 56                	push   %r14
    b108:	41 55                	push   %r13
    b10a:	41 54                	push   %r12
    b10c:	55                   	push   %rbp
    b10d:	53                   	push   %rbx
    b10e:	48 83 ec 38          	sub    $0x38,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b112:	48 8b 07             	mov    (%rdi),%rax
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b115:	4c 8b 30             	mov    (%rax),%r14
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1606
    b118:	4d 8b 86 08 15 00 00 	mov    0x1508(%r14),%r8
/usr/include/c++/13/bits/stl_vector.h:1933
    b11f:	4c 89 c5             	mov    %r8,%rbp
_M_erase_at_end():
/usr/include/c++/13/bits/stl_vector.h:1935
    b122:	4d 3b 86 10 15 00 00 	cmp    0x1510(%r14),%r8
    b129:	74 07                	je     b132 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x32>
/usr/include/c++/13/bits/stl_vector.h:1939
    b12b:	4d 89 86 10 15 00 00 	mov    %r8,0x1510(%r14)
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
    b132:	49 8b 86 40 15 00 00 	mov    0x1540(%r14),%rax
    b139:	4d 8b be 38 15 00 00 	mov    0x1538(%r14),%r15
    b140:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:444 (discriminator 1)
    b145:	4c 39 f8             	cmp    %r15,%rax
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:444 (discriminator 1)
    b148:	0f 84 a8 01 00 00    	je     b2f6 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1f6>
    b14e:	66 90                	xchg   %ax,%ax
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:444 (discriminator 3)
    b150:	4d 8b 0f             	mov    (%r15),%r9
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b153:	49 8b 91 70 02 00 00 	mov    0x270(%r9),%rdx
    b15a:	49 8b 81 68 02 00 00 	mov    0x268(%r9),%rax
    b161:	49 89 d4             	mov    %rdx,%r12
    b164:	49 29 c4             	sub    %rax,%r12
    b167:	49 c1 fc 02          	sar    $0x2,%r12
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 1)
    b16b:	48 39 c2             	cmp    %rax,%rdx
    b16e:	0f 84 dc 00 00 00    	je     b250 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x150>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:114
    b174:	4d 8b ae 18 15 00 00 	mov    0x1518(%r14),%r13
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446
    b17b:	31 db                	xor    %ebx,%ebx
    b17d:	eb 1e                	jmp    b19d <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x9d>
    b17f:	90                   	nop
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b180:	4c 89 4d 00          	mov    %r9,0x0(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b184:	48 83 c5 10          	add    $0x10,%rbp
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b188:	66 0f d6 4d f8       	movq   %xmm1,-0x8(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b18d:	49 89 ae 10 15 00 00 	mov    %rbp,0x1510(%r14)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 1)
    b194:	4c 39 e3             	cmp    %r12,%rbx
    b197:	0f 83 b3 00 00 00    	jae    b250 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x150>
    b19d:	66 0f 6e c3          	movd   %ebx,%xmm0
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:447
    b1a1:	48 83 c3 01          	add    $0x1,%rbx
unsigned long const& std::min<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:238
    b1a5:	49 39 dc             	cmp    %rbx,%r12
    b1a8:	48 89 da             	mov    %rbx,%rdx
    b1ab:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b1af:	49 0f 46 d4          	cmovbe %r12,%rdx
    b1b3:	66 0f 6e d2          	movd   %edx,%xmm2
    b1b7:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:114
    b1bb:	4c 39 ed             	cmp    %r13,%rbp
    b1be:	75 c0                	jne    b180 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x80>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b1c0:	48 b9 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rcx
    b1c7:	ff ff 07 
/usr/include/c++/13/bits/stl_vector.h:993
    b1ca:	48 89 ee             	mov    %rbp,%rsi
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b1cd:	4c 29 c6             	sub    %r8,%rsi
    b1d0:	48 89 f0             	mov    %rsi,%rax
    b1d3:	48 c1 f8 04          	sar    $0x4,%rax
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b1d7:	48 39 c8             	cmp    %rcx,%rax
    b1da:	0f 84 74 03 00 00    	je     b554 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x454>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
    b1e0:	4c 39 c5             	cmp    %r8,%rbp
    b1e3:	0f 84 6f 01 00 00    	je     b358 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x258>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
    b1e9:	48 8d 3c 00          	lea    (%rax,%rax,1),%rdi
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b1ed:	48 39 c7             	cmp    %rax,%rdi
    b1f0:	0f 82 ca 01 00 00    	jb     b3c0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c0>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:381
    b1f6:	48 85 ff             	test   %rdi,%rdi
_M_allocate():
/usr/include/c++/13/bits/stl_vector.h:381
    b1f9:	0f 85 38 03 00 00    	jne    b537 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x437>
    b1ff:	45 31 ed             	xor    %r13d,%r13d
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
    b202:	45 31 d2             	xor    %r10d,%r10d
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:468
    b205:	49 8d 04 32          	lea    (%r10,%rsi,1),%rax
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:483
    b209:	49 8d 6c 32 10       	lea    0x10(%r10,%rsi,1),%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b20e:	4c 89 08             	mov    %r9,(%rax)
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b211:	89 50 0c             	mov    %edx,0xc(%rax)
    b214:	66 0f 7e 40 08       	movd   %xmm0,0x8(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b219:	48 85 f6             	test   %rsi,%rsi
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b21c:	0f 8f e6 00 00 00    	jg     b308 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x208>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:389
    b222:	4d 85 c0             	test   %r8,%r8
_M_deallocate():
/usr/include/c++/13/bits/stl_vector.h:389
    b225:	0f 85 a5 01 00 00    	jne    b3d0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2d0>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:521
    b22b:	4d 89 96 08 15 00 00 	mov    %r10,0x1508(%r14)
/usr/include/c++/13/bits/vector.tcc:523
    b232:	4d 89 d0             	mov    %r10,%r8
/usr/include/c++/13/bits/vector.tcc:522
    b235:	49 89 ae 10 15 00 00 	mov    %rbp,0x1510(%r14)
/usr/include/c++/13/bits/vector.tcc:523
    b23c:	4d 89 ae 18 15 00 00 	mov    %r13,0x1518(%r14)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 1)
    b243:	4c 39 e3             	cmp    %r12,%rbx
    b246:	0f 82 51 ff ff ff    	jb     b19d <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x9d>
    b24c:	0f 1f 40 00          	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:444 (discriminator 1)
    b250:	49 83 c7 08          	add    $0x8,%r15
    b254:	4c 39 7c 24 28       	cmp    %r15,0x28(%rsp)
    b259:	0f 85 f1 fe ff ff    	jne    b150 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x50>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:993
    b25f:	4c 29 c5             	sub    %r8,%rbp
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:449 (discriminator 1)
    b262:	48 83 fd 30          	cmp    $0x30,%rbp
    b266:	0f 86 ce 01 00 00    	jbe    b43a <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x33a>
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b26c:	48 c1 fd 04          	sar    $0x4,%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25
    b270:	45 31 c9             	xor    %r9d,%r9d
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25
    b273:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:460
    b278:	49 8b 00             	mov    (%r8),%rax
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461
    b27b:	45 8b 50 08          	mov    0x8(%r8),%r10d
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461 (discriminator 2)
    b27f:	41 8b 78 0c          	mov    0xc(%r8),%edi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b283:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b287:	48 8b 48 70          	mov    0x70(%rax),%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461 (discriminator 2)
    b28b:	41 39 fa             	cmp    %edi,%r10d
    b28e:	73 59                	jae    b2e9 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1e9>
    b290:	89 fb                	mov    %edi,%ebx
    b292:	45 89 d3             	mov    %r10d,%r11d
    b295:	44 29 d3             	sub    %r10d,%ebx
    b298:	8d 43 ff             	lea    -0x1(%rbx),%eax
    b29b:	83 f8 01             	cmp    $0x1,%eax
    b29e:	76 1a                	jbe    b2ba <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1ba>
    b2a0:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b2a7:	00 
    b2a8:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    b2ac:	4c 8d 64 01 08       	lea    0x8(%rcx,%rax,1),%r12
    b2b1:	4c 39 e6             	cmp    %r12,%rsi
    b2b4:	0f 85 26 01 00 00    	jne    b3e0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2e0>
    b2ba:	83 ef 01             	sub    $0x1,%edi
    b2bd:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b2c4:	00 
    b2c5:	44 29 d7             	sub    %r10d,%edi
    b2c8:	4a 8d 7c 1f 01       	lea    0x1(%rdi,%r11,1),%rdi
    b2cd:	48 c1 e7 03          	shl    $0x3,%rdi
    b2d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b2d8:	48 8b 34 01          	mov    (%rcx,%rax,1),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b2dc:	48 01 34 02          	add    %rsi,(%rdx,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461 (discriminator 2)
    b2e0:	48 83 c0 08          	add    $0x8,%rax
    b2e4:	48 39 c7             	cmp    %rax,%rdi
    b2e7:	75 ef                	jne    b2d8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1d8>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25 (discriminator 3)
    b2e9:	49 83 c1 01          	add    $0x1,%r9
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25 (discriminator 2)
    b2ed:	49 83 c0 10          	add    $0x10,%r8
    b2f1:	49 39 e9             	cmp    %rbp,%r9
    b2f4:	72 82                	jb     b278 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b2f6:	48 83 c4 38          	add    $0x38,%rsp
    b2fa:	5b                   	pop    %rbx
    b2fb:	5d                   	pop    %rbp
    b2fc:	41 5c                	pop    %r12
    b2fe:	41 5d                	pop    %r13
    b300:	41 5e                	pop    %r14
    b302:	41 5f                	pop    %r15
    b304:	c3                   	ret
    b305:	0f 1f 00             	nopl   (%rax)
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b308:	48 89 f2             	mov    %rsi,%rdx
    b30b:	4c 89 d7             	mov    %r10,%rdi
    b30e:	4c 89 c6             	mov    %r8,%rsi
    b311:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    b316:	4c 89 04 24          	mov    %r8,(%rsp)
    b31a:	e8 01 bb ff ff       	call   6e20 <memmove@plt>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b31f:	49 8b b6 18 15 00 00 	mov    0x1518(%r14),%rsi
    b326:	4c 8b 04 24          	mov    (%rsp),%r8
    b32a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b32f:	49 89 c2             	mov    %rax,%r10
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b332:	4c 29 c6             	sub    %r8,%rsi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:172
    b335:	4c 89 c7             	mov    %r8,%rdi
deallocate():
/usr/include/c++/13/bits/new_allocator.h:172
    b338:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    b33d:	4c 89 0c 24          	mov    %r9,(%rsp)
    b341:	e8 2a b8 ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
    b346:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    b34b:	4c 8b 0c 24          	mov    (%rsp),%r9
    b34f:	e9 d7 fe ff ff       	jmp    b22b <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x12b>
    b354:	0f 1f 40 00          	nopl   0x0(%rax)
    b358:	48 83 c0 01          	add    $0x1,%rax
    b35c:	72 62                	jb     b3c0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c0>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b35e:	48 bf ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rdi
    b365:	ff ff 07 
    b368:	48 39 f8             	cmp    %rdi,%rax
    b36b:	48 0f 46 f8          	cmovbe %rax,%rdi
    b36f:	49 89 fd             	mov    %rdi,%r13
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:151
    b372:	49 c1 e5 04          	shl    $0x4,%r13
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b376:	4c 89 ef             	mov    %r13,%rdi
    b379:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b37e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    b383:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    b388:	4c 89 0c 24          	mov    %r9,(%rsp)
/usr/include/c++/13/bits/new_allocator.h:126
    b38c:	66 0f 7e 44 24 08    	movd   %xmm0,0x8(%rsp)
/usr/include/c++/13/bits/new_allocator.h:151
    b392:	e8 c9 b7 ff ff       	call   6b60 <operator new(unsigned long)@plt>
_M_allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b397:	4c 8b 0c 24          	mov    (%rsp),%r9
    b39b:	66 0f 6e 44 24 08    	movd   0x8(%rsp),%xmm0
    b3a1:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b3a6:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b3ab:	49 89 c2             	mov    %rax,%r10
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:523
    b3ae:	49 01 c5             	add    %rax,%r13
_M_allocate():
/usr/include/c++/13/bits/vector.tcc:523
    b3b1:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b3b6:	e9 4a fe ff ff       	jmp    b205 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x105>
    b3bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
_M_check_len():
/usr/include/c++/13/bits/vector.tcc:523
    b3c0:	49 bd f0 ff ff ff ff 	movabs $0x7ffffffffffffff0,%r13
    b3c7:	ff ff 7f 
    b3ca:	eb aa                	jmp    b376 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x276>
    b3cc:	0f 1f 40 00          	nopl   0x0(%rax)
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b3d0:	49 8b b6 18 15 00 00 	mov    0x1518(%r14),%rsi
    b3d7:	4c 29 c6             	sub    %r8,%rsi
    b3da:	e9 56 ff ff ff       	jmp    b335 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x235>
    b3df:	90                   	nop
    b3e0:	41 89 db             	mov    %ebx,%r11d
    b3e3:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461 (discriminator 2)
    b3e7:	31 c0                	xor    %eax,%eax
    b3e9:	41 d1 eb             	shr    $1,%r11d
    b3ec:	49 c1 e3 04          	shl    $0x4,%r11
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b3f0:	f3 0f 6f 04 07       	movdqu (%rdi,%rax,1),%xmm0
    b3f5:	f3 0f 6f 1c 06       	movdqu (%rsi,%rax,1),%xmm3
    b3fa:	66 0f d4 c3          	paddq  %xmm3,%xmm0
    b3fe:	0f 11 04 06          	movups %xmm0,(%rsi,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:461 (discriminator 2)
    b402:	48 83 c0 10          	add    $0x10,%rax
    b406:	49 39 c3             	cmp    %rax,%r11
    b409:	75 e5                	jne    b3f0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2f0>
    b40b:	89 d8                	mov    %ebx,%eax
    b40d:	83 e0 fe             	and    $0xfffffffe,%eax
    b410:	44 01 d0             	add    %r10d,%eax
    b413:	83 e3 01             	and    $0x1,%ebx
    b416:	0f 84 cd fe ff ff    	je     b2e9 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1e9>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25 (discriminator 3)
    b41c:	49 83 c1 01          	add    $0x1,%r9
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b420:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25 (discriminator 2)
    b424:	49 83 c0 10          	add    $0x10,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b428:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:25 (discriminator 2)
    b42c:	49 39 e9             	cmp    %rbp,%r9
    b42f:	0f 82 43 fe ff ff    	jb     b278 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
    b435:	e9 bc fe ff ff       	jmp    b2f6 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1f6>
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
    b43a:	4d 8b 86 38 15 00 00 	mov    0x1538(%r14),%r8
    b441:	4d 8b 8e 40 15 00 00 	mov    0x1540(%r14),%r9
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:451 (discriminator 1)
    b448:	4d 39 c8             	cmp    %r9,%r8
    b44b:	0f 84 a5 fe ff ff    	je     b2f6 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1f6>
    b451:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    b457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b45e:	00 00 
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:451 (discriminator 3)
    b460:	49 8b 00             	mov    (%r8),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b463:	4c 8b 98 70 02 00 00 	mov    0x270(%rax),%r11
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b46a:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b46e:	48 8b 48 70          	mov    0x70(%rax),%rcx
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b472:	48 8b 80 68 02 00 00 	mov    0x268(%rax),%rax
    b479:	4c 89 de             	mov    %r11,%rsi
    b47c:	48 29 c6             	sub    %rax,%rsi
    b47f:	48 89 f7             	mov    %rsi,%rdi
    b482:	48 c1 ff 02          	sar    $0x2,%rdi
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:454 (discriminator 2)
    b486:	49 39 c3             	cmp    %rax,%r11
    b489:	74 26                	je     b4b1 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3b1>
    b48b:	48 83 fe 08          	cmp    $0x8,%rsi
    b48f:	0f 86 9b 00 00 00    	jbe    b530 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x430>
    b495:	4c 8d 59 08          	lea    0x8(%rcx),%r11
    b499:	31 c0                	xor    %eax,%eax
    b49b:	4c 39 da             	cmp    %r11,%rdx
    b49e:	75 30                	jne    b4d0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3d0>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b4a0:	48 8b 34 c1          	mov    (%rcx,%rax,8),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b4a4:	48 01 34 c2          	add    %rsi,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:454 (discriminator 3)
    b4a8:	48 83 c0 01          	add    $0x1,%rax
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:454 (discriminator 2)
    b4ac:	48 39 f8             	cmp    %rdi,%rax
    b4af:	72 ef                	jb     b4a0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3a0>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:451 (discriminator 1)
    b4b1:	49 83 c0 08          	add    $0x8,%r8
    b4b5:	4d 39 c1             	cmp    %r8,%r9
    b4b8:	75 a6                	jne    b460 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x360>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b4ba:	48 83 c4 38          	add    $0x38,%rsp
    b4be:	5b                   	pop    %rbx
    b4bf:	5d                   	pop    %rbp
    b4c0:	41 5c                	pop    %r12
    b4c2:	41 5d                	pop    %r13
    b4c4:	41 5e                	pop    %r14
    b4c6:	41 5f                	pop    %r15
    b4c8:	c3                   	ret
    b4c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b4d0:	48 85 f6             	test   %rsi,%rsi
    b4d3:	49 0f 44 fa          	cmove  %r10,%rdi
    b4d7:	48 89 fe             	mov    %rdi,%rsi
    b4da:	48 d1 ee             	shr    $1,%rsi
    b4dd:	48 c1 e6 04          	shl    $0x4,%rsi
    b4e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b4e8:	f3 0f 6f 04 01       	movdqu (%rcx,%rax,1),%xmm0
    b4ed:	f3 0f 6f 24 02       	movdqu (%rdx,%rax,1),%xmm4
    b4f2:	66 0f d4 c4          	paddq  %xmm4,%xmm0
    b4f6:	0f 11 04 02          	movups %xmm0,(%rdx,%rax,1)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:454 (discriminator 2)
    b4fa:	48 83 c0 10          	add    $0x10,%rax
    b4fe:	48 39 c6             	cmp    %rax,%rsi
    b501:	75 e5                	jne    b4e8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3e8>
    b503:	48 89 f8             	mov    %rdi,%rax
    b506:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    b50a:	83 e7 01             	and    $0x1,%edi
    b50d:	74 a2                	je     b4b1 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3b1>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:451 (discriminator 1)
    b50f:	49 83 c0 08          	add    $0x8,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:73
    b513:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
    b517:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:451 (discriminator 1)
    b51b:	4d 39 c1             	cmp    %r8,%r9
    b51e:	0f 85 3c ff ff ff    	jne    b460 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x360>
    b524:	eb 94                	jmp    b4ba <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3ba>
    b526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b52d:	00 00 00 
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:454 (discriminator 2)
    b530:	31 c0                	xor    %eax,%eax
    b532:	e9 69 ff ff ff       	jmp    b4a0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3a0>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b537:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    b53e:	ff ff 07 
    b541:	48 39 c7             	cmp    %rax,%rdi
    b544:	48 0f 47 f8          	cmova  %rax,%rdi
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b548:	48 c1 e7 04          	shl    $0x4,%rdi
    b54c:	49 89 fd             	mov    %rdi,%r13
    b54f:	e9 22 fe ff ff       	jmp    b376 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x276>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1899
    b554:	48 8d 3d a9 da 04 00 	lea    0x4daa9(%rip),%rdi        # 59004 <_IO_stdin_used+0x4>
    b55b:	e8 60 b4 ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>


0000000000011810 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)>:
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:288
   11810:	f3 0f 1e fa          	endbr64
   11814:	41 57                	push   %r15
   11816:	41 56                	push   %r14
   11818:	41 55                	push   %r13
   1181a:	41 54                	push   %r12
   1181c:	55                   	push   %rbp
   1181d:	48 89 f5             	mov    %rsi,%rbp
   11820:	53                   	push   %rbx
   11821:	48 83 ec 48          	sub    $0x48,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   11825:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1182c:	00 00 
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   1182e:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   11833:	48 8b 07             	mov    (%rdi),%rax
   11836:	48 8b 00             	mov    (%rax),%rax
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
   11839:	48 8b 88 38 15 00 00 	mov    0x1538(%rax),%rcx
   11840:	4c 8b 90 40 15 00 00 	mov    0x1540(%rax),%r10
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   11847:	4c 39 d1             	cmp    %r10,%rcx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   1184a:	0f 84 03 04 00 00    	je     11c53 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x443>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:77
   11850:	31 d2                	xor    %edx,%edx
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:77
   11852:	eb 14                	jmp    11868 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   11854:	48 83 c1 08          	add    $0x8,%rcx
   11858:	49 39 ca             	cmp    %rcx,%r10
   1185b:	0f 84 97 00 00 00    	je     118f8 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xe8>
   11861:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 3)
   11868:	48 8b 01             	mov    (%rcx),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   1186b:	4c 8b 88 70 02 00 00 	mov    0x270(%rax),%r9
   11872:	4c 8b 80 68 02 00 00 	mov    0x268(%rax),%r8
   11879:	4c 89 ce             	mov    %r9,%rsi
   1187c:	4c 29 c6             	sub    %r8,%rsi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:197
   1187f:	49 89 f3             	mov    %rsi,%r11
   11882:	49 c1 fb 02          	sar    $0x2,%r11
   11886:	74 cc                	je     11854 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
   11888:	48 8b 78 68          	mov    0x68(%rax),%rdi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   1188c:	4d 39 c1             	cmp    %r8,%r9
   1188f:	74 c3                	je     11854 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
   11891:	48 83 fe 04          	cmp    $0x4,%rsi
   11895:	0f 84 38 01 00 00    	je     119d3 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1c3>
   1189b:	4c 89 de             	mov    %r11,%rsi
   1189e:	48 89 f8             	mov    %rdi,%rax
   118a1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   118a5:	48 d1 ee             	shr    $1,%rsi
   118a8:	48 c1 e6 04          	shl    $0x4,%rsi
   118ac:	48 01 fe             	add    %rdi,%rsi
   118af:	90                   	nop
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   118b0:	f3 0f 6f 10          	movdqu (%rax),%xmm2
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   118b4:	48 83 c0 10          	add    $0x10,%rax
   118b8:	66 0f d4 c2          	paddq  %xmm2,%xmm0
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   118bc:	48 39 c6             	cmp    %rax,%rsi
   118bf:	75 ef                	jne    118b0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xa0>
   118c1:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   118c5:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
   118ca:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   118ce:	66 48 0f 7e c0       	movq   %xmm0,%rax
   118d3:	48 01 c2             	add    %rax,%rdx
   118d6:	4c 89 d8             	mov    %r11,%rax
   118d9:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   118dd:	41 83 e3 01          	and    $0x1,%r11d
   118e1:	0f 84 6d ff ff ff    	je     11854 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   118e7:	48 83 c1 08          	add    $0x8,%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   118eb:	48 03 14 c7          	add    (%rdi,%rax,8),%rdx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   118ef:	49 39 ca             	cmp    %rcx,%r10
   118f2:	0f 85 70 ff ff ff    	jne    11868 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   118f8:	48 85 d2             	test   %rdx,%rdx
   118fb:	0f 88 af 00 00 00    	js     119b0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1a0>
   11901:	66 0f ef e4          	pxor   %xmm4,%xmm4
   11905:	f2 48 0f 2a e2       	cvtsi2sd %rdx,%xmm4
   1190a:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   1190f:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   11914:	c6 44 24 28 00       	movb   $0x0,0x28(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   11919:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   11920:	73 75 6d 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   11923:	48 8b 9d 50 01 00 00 	mov    0x150(%rbp),%rbx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   1192a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   1192f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11934:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   1193b:	00 00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   1193d:	48 3b 9d 58 01 00 00 	cmp    0x158(%rbp),%rbx
   11944:	0f 84 90 00 00 00    	je     119da <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1ca>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   1194a:	48 8d 53 10          	lea    0x10(%rbx),%rdx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   1194e:	48 89 13             	mov    %rdx,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   11951:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   11956:	4c 39 e0             	cmp    %r12,%rax
   11959:	0f 84 e1 02 00 00    	je     11c40 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x430>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   1195f:	48 89 03             	mov    %rax,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   11962:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   11967:	48 89 43 10          	mov    %rax,0x10(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   1196b:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11970:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
   11977:	00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   11978:	f2 0f 11 5b 20       	movsd  %xmm3,0x20(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:119
   1197d:	48 83 85 50 01 00 00 	addq   $0x28,0x150(%rbp)
   11984:	28 
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   11985:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1198a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   11991:	00 00 
   11993:	0f 85 8f 03 00 00    	jne    11d28 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   11999:	48 83 c4 48          	add    $0x48,%rsp
   1199d:	5b                   	pop    %rbx
   1199e:	5d                   	pop    %rbp
   1199f:	41 5c                	pop    %r12
   119a1:	41 5d                	pop    %r13
   119a3:	41 5e                	pop    %r14
   119a5:	41 5f                	pop    %r15
   119a7:	c3                   	ret
   119a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   119af:	00 
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   119b0:	48 89 d0             	mov    %rdx,%rax
   119b3:	83 e2 01             	and    $0x1,%edx
   119b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   119ba:	48 d1 e8             	shr    $1,%rax
   119bd:	48 09 d0             	or     %rdx,%rax
   119c0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   119c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   119c9:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
   119ce:	e9 3c ff ff ff       	jmp    1190f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199
   119d3:	31 c0                	xor    %eax,%eax
   119d5:	e9 0d ff ff ff       	jmp    118e7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xd7>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:445
   119da:	4c 8b ad 48 01 00 00 	mov    0x148(%rbp),%r13
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   119e1:	49 89 de             	mov    %rbx,%r14
   119e4:	48 ba cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rdx
   119eb:	cc cc cc 
   119ee:	4d 29 ee             	sub    %r13,%r14
   119f1:	4c 89 f0             	mov    %r14,%rax
   119f4:	48 c1 f8 03          	sar    $0x3,%rax
   119f8:	48 0f af c2          	imul   %rdx,%rax
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
   119fc:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   11a03:	33 33 03 
   11a06:	48 39 d0             	cmp    %rdx,%rax
   11a09:	0f 84 1e 03 00 00    	je     11d2d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x51d>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
   11a0f:	4c 39 eb             	cmp    %r13,%rbx
   11a12:	74 6c                	je     11a80 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x270>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
   11a14:	48 8d 14 00          	lea    (%rax,%rax,1),%rdx
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   11a18:	48 39 c2             	cmp    %rax,%rdx
   11a1b:	0f 82 3f 02 00 00    	jb     11c60 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381
   11a21:	48 85 d2             	test   %rdx,%rdx
   11a24:	0f 85 e4 02 00 00    	jne    11d0e <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4fe>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   11a2a:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   11a2e:	41 bf 28 00 00 00    	mov    $0x28,%r15d
   11a34:	ba 08 00 00 00       	mov    $0x8,%edx
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
   11a39:	45 31 c0             	xor    %r8d,%r8d
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   11a3c:	49 89 0e             	mov    %rcx,(%r14)
   11a3f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   11a46:	00 00 
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   11a48:	48 8d 42 01          	lea    0x1(%rdx),%rax
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   11a4c:	83 f8 08             	cmp    $0x8,%eax
   11a4f:	0f 83 1a 02 00 00    	jae    11c6f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x45f>
   11a55:	a8 04                	test   $0x4,%al
   11a57:	0f 85 8f 02 00 00    	jne    11cec <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4dc>
   11a5d:	85 c0                	test   %eax,%eax
   11a5f:	74 7c                	je     11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   11a61:	0f b6 74 24 20       	movzbl 0x20(%rsp),%esi
   11a66:	40 88 31             	mov    %sil,(%rcx)
   11a69:	a8 02                	test   $0x2,%al
   11a6b:	74 70                	je     11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   11a6d:	89 c0                	mov    %eax,%eax
   11a6f:	41 0f b7 74 04 fe    	movzwl -0x2(%r12,%rax,1),%esi
   11a75:	66 89 74 01 fe       	mov    %si,-0x2(%rcx,%rax,1)
   11a7a:	eb 61                	jmp    11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   11a7c:	0f 1f 40 00          	nopl   0x0(%rax)
   11a80:	48 83 c0 01          	add    $0x1,%rax
   11a84:	0f 82 d6 01 00 00    	jb     11c60 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   11a8a:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   11a91:	33 33 03 
   11a94:	48 39 d0             	cmp    %rdx,%rax
   11a97:	48 0f 47 c2          	cmova  %rdx,%rax
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   11a9b:	4c 8d 3c 80          	lea    (%rax,%rax,4),%r15
   11a9f:	49 c1 e7 03          	shl    $0x3,%r15
   11aa3:	4c 89 ff             	mov    %r15,%rdi
   11aa6:	e8 b5 50 ff ff       	call   6b60 <operator new(unsigned long)@plt>
   11aab:	49 89 c0             	mov    %rax,%r8
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   11aae:	4a 8d 04 38          	lea    (%rax,%r15,1),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:266
   11ab2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   11ab7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   11abc:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   11ac1:	4d 8d 78 28          	lea    0x28(%r8),%r15
/usr/include/c++/13/bits/vector.tcc:468
   11ac5:	4d 01 c6             	add    %r8,%r14
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   11ac8:	4c 39 e0             	cmp    %r12,%rax
   11acb:	0f 84 31 02 00 00    	je     11d02 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4f2>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   11ad1:	49 89 06             	mov    %rax,(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   11ad4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   11ad9:	49 89 46 10          	mov    %rax,0x10(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   11add:	f2 0f 10 2c 24       	movsd  (%rsp),%xmm5
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11ae2:	49 89 56 08          	mov    %rdx,0x8(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   11ae6:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11aeb:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   11af2:	00 00 
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   11af4:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   11af9:	f2 41 0f 11 6e 20    	movsd  %xmm5,0x20(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   11aff:	4c 39 eb             	cmp    %r13,%rbx
   11b02:	0f 84 8f 00 00 00    	je     11b97 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x387>
   11b08:	4c 89 e8             	mov    %r13,%rax
/usr/include/c++/13/bits/stl_uninitialized.h:1103
   11b0b:	4c 89 c2             	mov    %r8,%rdx
   11b0e:	eb 2a                	jmp    11b3a <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x32a>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   11b10:	48 89 0a             	mov    %rcx,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   11b13:	48 8b 48 10          	mov    0x10(%rax),%rcx
   11b17:	48 89 4a 10          	mov    %rcx,0x10(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11b1b:	48 8b 48 08          	mov    0x8(%rax),%rcx
   11b1f:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   11b23:	f2 0f 10 40 20       	movsd  0x20(%rax),%xmm0
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 2)
   11b28:	48 83 c0 28          	add    $0x28,%rax
   11b2c:	48 83 c2 28          	add    $0x28,%rdx
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   11b30:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   11b35:	48 39 c3             	cmp    %rax,%rbx
   11b38:	74 4d                	je     11b87 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x377>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   11b3a:	48 8d 72 10          	lea    0x10(%rdx),%rsi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:241
   11b3e:	48 8d 78 10          	lea    0x10(%rax),%rdi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   11b42:	48 89 32             	mov    %rsi,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   11b45:	48 8b 08             	mov    (%rax),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   11b48:	48 39 f9             	cmp    %rdi,%rcx
   11b4b:	75 c3                	jne    11b10 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x300>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   11b4d:	4c 8b 48 08          	mov    0x8(%rax),%r9
   11b51:	49 8d 79 01          	lea    0x1(%r9),%rdi
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   11b55:	83 ff 08             	cmp    $0x8,%edi
   11b58:	0f 83 97 00 00 00    	jae    11bf5 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x3e5>
   11b5e:	40 f6 c7 04          	test   $0x4,%dil
   11b62:	0f 85 56 01 00 00    	jne    11cbe <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4ae>
   11b68:	85 ff                	test   %edi,%edi
   11b6a:	74 15                	je     11b81 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   11b6c:	44 0f b6 09          	movzbl (%rcx),%r9d
   11b70:	44 88 0e             	mov    %r9b,(%rsi)
   11b73:	40 f6 c7 02          	test   $0x2,%dil
   11b77:	0f 85 5a 01 00 00    	jne    11cd7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4c7>
   11b7d:	4c 8b 48 08          	mov    0x8(%rax),%r9
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   11b81:	4c 89 4a 08          	mov    %r9,0x8(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_set_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:254
   11b85:	eb 9c                	jmp    11b23 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x313>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   11b87:	48 8d 43 d8          	lea    -0x28(%rbx),%rax
   11b8b:	4c 29 e8             	sub    %r13,%rax
   11b8e:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   11b92:	4d 8d 7c 00 50       	lea    0x50(%r8,%rax,1),%r15
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/stl_vector.h:389
   11b97:	4d 85 ed             	test   %r13,%r13
   11b9a:	0f 84 a9 01 00 00    	je     11d49 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x539>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   11ba0:	48 8b b5 58 01 00 00 	mov    0x158(%rbp),%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   11ba7:	4c 89 ef             	mov    %r13,%rdi
   11baa:	4c 89 04 24          	mov    %r8,(%rsp)
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   11bae:	4c 29 ee             	sub    %r13,%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   11bb1:	e8 ba 4f ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   11bb6:	4c 8b 04 24          	mov    (%rsp),%r8
/usr/include/c++/13/bits/vector.tcc:523
   11bba:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:522
   11bbf:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   11bc6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   11bcb:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   11bd2:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   11bd9:	4c 39 e7             	cmp    %r12,%rdi
   11bdc:	0f 84 a3 fd ff ff    	je     11985 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_destroy(unsigned long):
/usr/include/c++/13/bits/basic_string.h:289
   11be2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   11be7:	48 8d 70 01          	lea    0x1(%rax),%rsi
std::__new_allocator<char>::deallocate(char*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   11beb:	e8 80 4f ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:291
   11bf0:	e9 90 fd ff ff       	jmp    11985 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   11bf5:	4c 8b 09             	mov    (%rcx),%r9
   11bf8:	4c 89 0e             	mov    %r9,(%rsi)
   11bfb:	41 89 f9             	mov    %edi,%r9d
   11bfe:	4e 8b 54 09 f8       	mov    -0x8(%rcx,%r9,1),%r10
   11c03:	4e 89 54 0e f8       	mov    %r10,-0x8(%rsi,%r9,1)
   11c08:	4c 8d 4a 18          	lea    0x18(%rdx),%r9
   11c0c:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
   11c10:	4c 29 ce             	sub    %r9,%rsi
   11c13:	01 f7                	add    %esi,%edi
   11c15:	48 29 f1             	sub    %rsi,%rcx
   11c18:	83 e7 f8             	and    $0xfffffff8,%edi
   11c1b:	83 ff 08             	cmp    $0x8,%edi
   11c1e:	0f 82 59 ff ff ff    	jb     11b7d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   11c24:	83 e7 f8             	and    $0xfffffff8,%edi
   11c27:	31 f6                	xor    %esi,%esi
   11c29:	41 89 f2             	mov    %esi,%r10d
   11c2c:	83 c6 08             	add    $0x8,%esi
   11c2f:	4e 8b 1c 11          	mov    (%rcx,%r10,1),%r11
   11c33:	4f 89 1c 11          	mov    %r11,(%r9,%r10,1)
   11c37:	39 fe                	cmp    %edi,%esi
   11c39:	72 ee                	jb     11c29 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x419>
   11c3b:	e9 3d ff ff ff       	jmp    11b7d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   11c40:	48 8b 08             	mov    (%rax),%rcx
   11c43:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   11c47:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   11c4b:	88 42 08             	mov    %al,0x8(%rdx)
   11c4e:	e9 18 fd ff ff       	jmp    1196b <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x15b>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   11c53:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   11c5a:	00 
   11c5b:	e9 af fc ff ff       	jmp    1190f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   11c60:	49 bf f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r15
   11c67:	ff ff 7f 
   11c6a:	e9 34 fe ff ff       	jmp    11aa3 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   11c6f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   11c74:	48 89 31             	mov    %rsi,(%rcx)
   11c77:	89 c6                	mov    %eax,%esi
   11c79:	49 8b 7c 34 f8       	mov    -0x8(%r12,%rsi,1),%rdi
   11c7e:	48 89 7c 31 f8       	mov    %rdi,-0x8(%rcx,%rsi,1)
   11c83:	48 8d 71 08          	lea    0x8(%rcx),%rsi
   11c87:	4c 89 e7             	mov    %r12,%rdi
   11c8a:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   11c8e:	48 29 f1             	sub    %rsi,%rcx
   11c91:	01 c8                	add    %ecx,%eax
   11c93:	48 29 cf             	sub    %rcx,%rdi
   11c96:	83 e0 f8             	and    $0xfffffff8,%eax
   11c99:	83 f8 08             	cmp    $0x8,%eax
   11c9c:	0f 82 3b fe ff ff    	jb     11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   11ca2:	83 e0 f8             	and    $0xfffffff8,%eax
   11ca5:	31 c9                	xor    %ecx,%ecx
   11ca7:	41 89 c9             	mov    %ecx,%r9d
   11caa:	83 c1 08             	add    $0x8,%ecx
   11cad:	4e 8b 14 0f          	mov    (%rdi,%r9,1),%r10
   11cb1:	4e 89 14 0e          	mov    %r10,(%rsi,%r9,1)
   11cb5:	39 c1                	cmp    %eax,%ecx
   11cb7:	72 ee                	jb     11ca7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x497>
   11cb9:	e9 1f fe ff ff       	jmp    11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   11cbe:	44 8b 09             	mov    (%rcx),%r9d
   11cc1:	89 ff                	mov    %edi,%edi
   11cc3:	44 89 0e             	mov    %r9d,(%rsi)
   11cc6:	8b 4c 39 fc          	mov    -0x4(%rcx,%rdi,1),%ecx
   11cca:	89 4c 3e fc          	mov    %ecx,-0x4(%rsi,%rdi,1)
   11cce:	4c 8b 48 08          	mov    0x8(%rax),%r9
   11cd2:	e9 aa fe ff ff       	jmp    11b81 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   11cd7:	89 ff                	mov    %edi,%edi
   11cd9:	0f b7 4c 39 fe       	movzwl -0x2(%rcx,%rdi,1),%ecx
   11cde:	66 89 4c 3e fe       	mov    %cx,-0x2(%rsi,%rdi,1)
   11ce3:	4c 8b 48 08          	mov    0x8(%rax),%r9
   11ce7:	e9 95 fe ff ff       	jmp    11b81 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   11cec:	8b 74 24 20          	mov    0x20(%rsp),%esi
   11cf0:	89 c0                	mov    %eax,%eax
   11cf2:	89 31                	mov    %esi,(%rcx)
   11cf4:	41 8b 74 04 fc       	mov    -0x4(%r12,%rax,1),%esi
   11cf9:	89 74 01 fc          	mov    %esi,-0x4(%rcx,%rax,1)
   11cfd:	e9 db fd ff ff       	jmp    11add <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   11d02:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   11d06:	49 89 0e             	mov    %rcx,(%r14)
   11d09:	e9 3a fd ff ff       	jmp    11a48 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x238>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   11d0e:	48 b8 33 33 33 33 33 	movabs $0x333333333333333,%rax
   11d15:	33 33 03 
   11d18:	48 39 c2             	cmp    %rax,%rdx
   11d1b:	48 0f 47 d0          	cmova  %rax,%rdx
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   11d1f:	4c 6b fa 28          	imul   $0x28,%rdx,%r15
   11d23:	e9 7b fd ff ff       	jmp    11aa3 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   11d28:	e8 a3 4e ff ff       	call   6bd0 <__stack_chk_fail@plt>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1899
   11d2d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   11d32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   11d39:	00 00 
   11d3b:	75 eb                	jne    11d28 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   11d3d:	48 8d 3d c0 72 04 00 	lea    0x472c0(%rip),%rdi        # 59004 <_IO_stdin_used+0x4>
   11d44:	e8 77 4c ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   11d49:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:521
   11d4e:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:522
   11d55:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   11d5c:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:238
   11d63:	e9 1d fc ff ff       	jmp    11985 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
   11d68:	f3 0f 1e fa          	endbr64
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
   11d6c:	48 89 c3             	mov    %rax,%rbx
   11d6f:	e9 ca 55 ff ff       	jmp    733e <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/basic_string.h:804
   11d74:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   11d7b:	00 00 00 00 
   11d7f:	90                   	nop


0000000000017690 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   17690:	f3 0f 1e fa          	endbr64
   17694:	41 57                	push   %r15
   17696:	41 56                	push   %r14
   17698:	41 55                	push   %r13
   1769a:	41 54                	push   %r12
   1769c:	55                   	push   %rbp
   1769d:	53                   	push   %rbx
   1769e:	48 89 fb             	mov    %rdi,%rbx
/usr/include/c++/13/bits/new_allocator.h:151
   176a1:	bf 68 15 00 00       	mov    $0x1568,%edi
/usr/include/c++/13/bits/std_function.h:288
   176a6:	48 83 ec 38          	sub    $0x38,%rsp
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:97
   176aa:	44 0f b6 76 08       	movzbl 0x8(%rsi),%r14d
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:97
   176af:	4c 8b 3e             	mov    (%rsi),%r15
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   176b2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   176b9:	00 00 
   176bb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   176c0:	31 c0                	xor    %eax,%eax
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
   176c2:	e8 99 f4 fe ff       	call   6b60 <operator new(unsigned long)@plt>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:119 (discriminator 1)
   176c7:	41 0f b6 d6          	movzbl %r14b,%edx
_Construct<(anonymous namespace)::Ecs<0>, long unsigned int&, bool&>():
/usr/include/c++/13/bits/stl_construct.h:119 (discriminator 1)
   176cb:	4c 89 fe             	mov    %r15,%rsi
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
   176ce:	48 89 c5             	mov    %rax,%rbp
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_Sp_counted_base():
/usr/include/c++/13/bits/shared_ptr_base.h:130
   176d1:	48 8b 05 30 2d 04 00 	mov    0x42d30(%rip),%rax        # 5a408 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x10>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/ext/aligned_buffer.h:106
   176d8:	4c 8d 65 10          	lea    0x10(%rbp),%r12
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_Sp_counted_base():
/usr/include/c++/13/bits/shared_ptr_base.h:130
   176dc:	48 89 45 08          	mov    %rax,0x8(%rbp)
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/shared_ptr_base.h:600 (discriminator 1)
   176e0:	48 8d 05 39 38 05 00 	lea    0x53839(%rip),%rax        # 6af20 <vtable for std::_Sp_counted_ptr_inplace<(anonymous namespace)::Ecs<1ul>, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>+0x10>
_Construct<(anonymous namespace)::Ecs<0>, long unsigned int&, bool&>():
/usr/include/c++/13/bits/stl_construct.h:119 (discriminator 1)
   176e7:	4c 89 e7             	mov    %r12,%rdi
_Sp_counted_ptr_inplace<long unsigned int&, bool&>():
/usr/include/c++/13/bits/shared_ptr_base.h:600 (discriminator 1)
   176ea:	48 89 45 00          	mov    %rax,0x0(%rbp)
_Construct<(anonymous namespace)::Ecs<0>, long unsigned int&, bool&>():
/usr/include/c++/13/bits/stl_construct.h:119 (discriminator 1)
   176ee:	e8 5d bc ff ff       	call   13350 <(anonymous namespace)::Ecs<0ul>::Ecs(unsigned long, bool)>
std::function<void ()>::function():
/usr/include/c++/13/bits/std_function.h:369
   176f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
__gnu_cxx::__atomic_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:108 (discriminator 1)
   176f7:	80 3d 62 4d 05 00 00 	cmpb   $0x0,0x54d62(%rip)        # 6c460 <__libc_single_threaded@GLIBC_2.32>
std::function<void ()>::function():
/usr/include/c++/13/bits/std_function.h:369
   176fe:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
   17705:	00 
   17706:	4c 8d 6d 08          	lea    0x8(%rbp),%r13
/usr/include/c++/13/bits/std_function.h:369 (discriminator 1)
   1770a:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
   17711:	00 
/usr/include/c++/13/bits/std_function.h:369
   17712:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
   17719:	00 
/usr/include/c++/13/bits/std_function.h:369 (discriminator 1)
   1771a:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
   17721:	00 
std::function<void (bench::harness::Record&)>::function():
/usr/include/c++/13/bits/std_function.h:369
   17722:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
   17729:	00 
/usr/include/c++/13/bits/std_function.h:369 (discriminator 1)
   1772a:	48 c7 43 58 00 00 00 	movq   $0x0,0x58(%rbx)
   17731:	00 
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::__shared_count():
/usr/include/c++/13/bits/shared_ptr_base.h:908
   17732:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
   17739:	00 
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1599
   1773a:	4c 89 63 60          	mov    %r12,0x60(%rbx)
std::function<void ()>::function():
/usr/include/c++/13/bits/std_function.h:369
   1773e:	0f 11 03             	movups %xmm0,(%rbx)
   17741:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
std::function<void (bench::harness::Record&)>::function():
/usr/include/c++/13/bits/std_function.h:369
   17745:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
__gnu_cxx::__atomic_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:108 (discriminator 1)
   17749:	0f 84 81 01 00 00    	je     178d0 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x240>
__gnu_cxx::__atomic_add_single(int*, int):
/usr/include/c++/13/ext/atomicity.h:92
   1774f:	83 45 08 01          	addl   $0x1,0x8(%rbp)
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::operator=(std::__shared_count<(__gnu_cxx::_Lock_policy)2> const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1091
   17753:	48 89 6b 68          	mov    %rbp,0x68(%rbx)
__gnu_cxx::__atomic_add_single(int*, int):
/usr/include/c++/13/ext/atomicity.h:92
   17757:	83 45 08 01          	addl   $0x1,0x8(%rbp)
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:437
   1775b:	66 0f ef c0          	pxor   %xmm0,%xmm0
/usr/include/c++/13/bits/std_function.h:161
   1775f:	bf 10 00 00 00       	mov    $0x10,%edi
function<(anonymous namespace)::prepare<Ecs<1> >(std::size_t, bool)::<lambda()> >():
/usr/include/c++/13/bits/std_function.h:437
   17764:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   1776b:	00 00 
/usr/include/c++/13/bits/std_function.h:437 (discriminator 1)
   1776d:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   17774:	00 00 
/usr/include/c++/13/bits/std_function.h:437
   17776:	0f 29 04 24          	movaps %xmm0,(%rsp)
_M_create<(anonymous namespace)::prepare<Ecs<1> >(std::size_t, bool)::<lambda()> >():
/usr/include/c++/13/bits/std_function.h:161
   1777a:	e8 e1 f3 fe ff       	call   6b60 <operator new(unsigned long)@plt>
   1777f:	48 89 04 24          	mov    %rax,(%rsp)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:197
   17783:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   17788:	48 8d 15 71 39 ff ff 	lea    -0xc68f(%rip),%rdx        # b100 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>
   1778f:	48 8d 0d 8a 84 ff ff 	lea    -0x7b76(%rip),%rcx        # fc20 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:198
   17796:	f3 0f 6f 0b          	movdqu (%rbx),%xmm1
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:198
   1779a:	f3 0f 6f 53 10       	movdqu 0x10(%rbx),%xmm2
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1532
   1779f:	4c 89 20             	mov    %r12,(%rax)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   177a2:	66 48 0f 6e da       	movq   %rdx,%xmm3
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::_M_swap(std::__shared_count<(__gnu_cxx::_Lock_policy)2>&):
/usr/include/c++/13/bits/shared_ptr_base.h:1101
   177a7:	48 89 68 08          	mov    %rbp,0x8(%rax)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:189
   177ab:	48 8b 43 10          	mov    0x10(%rbx),%rax
/usr/include/c++/13/bits/move.h:199
   177af:	0f 11 03             	movups %xmm0,(%rbx)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   177b2:	66 48 0f 6e c1       	movq   %rcx,%xmm0
   177b7:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:198
   177bb:	0f 29 0c 24          	movaps %xmm1,(%rsp)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:198
   177bf:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
/usr/include/c++/13/bits/move.h:199
   177c4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
std::_Function_base::~_Function_base():
/usr/include/c++/13/bits/std_function.h:243
   177c8:	48 85 c0             	test   %rax,%rax
   177cb:	74 0d                	je     177da <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x14a>
/usr/include/c++/13/bits/std_function.h:244
   177cd:	48 89 e7             	mov    %rsp,%rdi
   177d0:	ba 03 00 00 00       	mov    $0x3,%edx
   177d5:	48 89 fe             	mov    %rdi,%rsi
   177d8:	ff d0                	call   *%rax
__gnu_cxx::__atomic_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:108 (discriminator 1)
   177da:	80 3d 7f 4c 05 00 00 	cmpb   $0x0,0x54c7f(%rip)        # 6c460 <__libc_single_threaded@GLIBC_2.32>
   177e1:	0f 84 51 01 00 00    	je     17938 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2a8>
__gnu_cxx::__atomic_add_single(int*, int):
/usr/include/c++/13/ext/atomicity.h:92
   177e7:	83 45 08 01          	addl   $0x1,0x8(%rbp)
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:437
   177eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
/usr/include/c++/13/bits/std_function.h:161
   177ef:	bf 10 00 00 00       	mov    $0x10,%edi
function<(anonymous namespace)::prepare<Ecs<1> >(std::size_t, bool)::<lambda(bench::harness::Record&)> >():
/usr/include/c++/13/bits/std_function.h:437
   177f4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   177fb:	00 00 
/usr/include/c++/13/bits/std_function.h:437 (discriminator 1)
   177fd:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   17804:	00 00 
/usr/include/c++/13/bits/std_function.h:437
   17806:	0f 29 04 24          	movaps %xmm0,(%rsp)
_M_create<(anonymous namespace)::prepare<Ecs<1> >(std::size_t, bool)::<lambda(bench::harness::Record&)> >():
/usr/include/c++/13/bits/std_function.h:161
   1780a:	e8 51 f3 fe ff       	call   6b60 <operator new(unsigned long)@plt>
   1780f:	48 89 04 24          	mov    %rax,(%rsp)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:197
   17813:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   17818:	48 8d 15 f1 9f ff ff 	lea    -0x600f(%rip),%rdx        # 11810 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)>
   1781f:	48 8d 0d 2a 85 ff ff 	lea    -0x7ad6(%rip),%rcx        # fd50 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:198
   17826:	f3 0f 6f 63 40       	movdqu 0x40(%rbx),%xmm4
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:198
   1782b:	f3 0f 6f 6b 50       	movdqu 0x50(%rbx),%xmm5
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1532
   17830:	4c 89 20             	mov    %r12,(%rax)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   17833:	66 48 0f 6e f2       	movq   %rdx,%xmm6
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::_M_swap(std::__shared_count<(__gnu_cxx::_Lock_policy)2>&):
/usr/include/c++/13/bits/shared_ptr_base.h:1101
   17838:	48 89 68 08          	mov    %rbp,0x8(%rax)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:189
   1783c:	48 8b 43 50          	mov    0x50(%rbx),%rax
/usr/include/c++/13/bits/move.h:199
   17840:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:199
   17844:	66 48 0f 6e c1       	movq   %rcx,%xmm0
   17849:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<std::_Any_data> >, std::is_move_constructible<std::_Any_data>, std::is_move_assignable<std::_Any_data> >::value, void>::type std::swap<std::_Any_data>(std::_Any_data&, std::_Any_data&):
/usr/include/c++/13/bits/move.h:198
   1784d:	0f 29 24 24          	movaps %xmm4,(%rsp)
std::enable_if<std::__and_<std::__not_<std::__is_tuple_like<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >, std::is_move_constructible<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>, std::is_move_assignable<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)> >::value, void>::type std::swap<bool (*)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>(bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation), bool (*&)(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)):
/usr/include/c++/13/bits/move.h:198
   17851:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
/usr/include/c++/13/bits/move.h:199
   17856:	0f 11 43 50          	movups %xmm0,0x50(%rbx)
std::_Function_base::~_Function_base():
/usr/include/c++/13/bits/std_function.h:243
   1785a:	48 85 c0             	test   %rax,%rax
   1785d:	74 0d                	je     1786c <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1dc>
/usr/include/c++/13/bits/std_function.h:244
   1785f:	48 89 e7             	mov    %rsp,%rdi
   17862:	ba 03 00 00 00       	mov    $0x3,%edx
   17867:	48 89 fe             	mov    %rdi,%rsi
   1786a:	ff d0                	call   *%rax
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:337 (discriminator 1)
   1786c:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   17873:	00 00 00 
/usr/include/c++/13/bits/shared_ptr_base.h:337
   17876:	48 8b 55 08          	mov    0x8(%rbp),%rdx
/usr/include/c++/13/bits/shared_ptr_base.h:337 (discriminator 1)
   1787a:	48 39 c2             	cmp    %rax,%rdx
   1787d:	0f 84 ed 00 00 00    	je     17970 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2e0>
__gnu_cxx::__exchange_and_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:98 (discriminator 1)
   17883:	80 3d d6 4b 05 00 00 	cmpb   $0x0,0x54bd6(%rip)        # 6c460 <__libc_single_threaded@GLIBC_2.32>
   1788a:	0f 84 c8 00 00 00    	je     17958 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c8>
__gnu_cxx::__exchange_and_add_single(int*, int):
/usr/include/c++/13/ext/atomicity.h:84
   17890:	8b 45 08             	mov    0x8(%rbp),%eax
/usr/include/c++/13/ext/atomicity.h:85
   17893:	8d 50 ff             	lea    -0x1(%rax),%edx
   17896:	89 55 08             	mov    %edx,0x8(%rbp)
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:350 (discriminator 1)
   17899:	83 f8 01             	cmp    $0x1,%eax
   1789c:	0f 84 2e 01 00 00    	je     179d0 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x340>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
   178a2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   178a7:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   178ae:	00 00 
   178b0:	0f 85 27 01 00 00    	jne    179dd <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x34d>
   178b6:	48 83 c4 38          	add    $0x38,%rsp
   178ba:	48 89 d8             	mov    %rbx,%rax
   178bd:	5b                   	pop    %rbx
   178be:	5d                   	pop    %rbp
   178bf:	41 5c                	pop    %r12
   178c1:	41 5d                	pop    %r13
   178c3:	41 5e                	pop    %r14
   178c5:	41 5f                	pop    %r15
   178c7:	c3                   	ret
   178c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   178cf:	00 
__gnu_cxx::__atomic_add(int volatile*, int):
/usr/include/c++/13/ext/atomicity.h:71
   178d0:	f0 83 45 08 01       	lock addl $0x1,0x8(%rbp)
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::operator=(std::__shared_count<(__gnu_cxx::_Lock_policy)2> const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1089
   178d5:	4c 8b 73 68          	mov    0x68(%rbx),%r14
   178d9:	4d 85 f6             	test   %r14,%r14
   178dc:	74 38                	je     17916 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x286>
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:337
   178de:	49 8b 56 08          	mov    0x8(%r14),%rdx
/usr/include/c++/13/bits/shared_ptr_base.h:334
   178e2:	49 8d 4e 08          	lea    0x8(%r14),%rcx
/usr/include/c++/13/bits/shared_ptr_base.h:337 (discriminator 1)
   178e6:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   178ed:	00 00 00 
   178f0:	48 39 c2             	cmp    %rax,%rdx
   178f3:	0f 84 9f 00 00 00    	je     17998 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x308>
__gnu_cxx::__exchange_and_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:98 (discriminator 1)
   178f9:	80 3d 60 4b 05 00 00 	cmpb   $0x0,0x54b60(%rip)        # 6c460 <__libc_single_threaded@GLIBC_2.32>
   17900:	74 46                	je     17948 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b8>
__gnu_cxx::__exchange_and_add_single(int*, int):
/usr/include/c++/13/ext/atomicity.h:84
   17902:	41 8b 46 08          	mov    0x8(%r14),%eax
/usr/include/c++/13/ext/atomicity.h:85
   17906:	8d 50 ff             	lea    -0x1(%rax),%edx
   17909:	41 89 56 08          	mov    %edx,0x8(%r14)
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:350 (discriminator 1)
   1790d:	83 f8 01             	cmp    $0x1,%eax
   17910:	0f 84 aa 00 00 00    	je     179c0 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x330>
__gnu_cxx::__is_single_threaded():
/usr/include/c++/13/ext/atomicity.h:52
   17916:	0f b6 05 43 4b 05 00 	movzbl 0x54b43(%rip),%eax        # 6c460 <__libc_single_threaded@GLIBC_2.32>
std::__shared_count<(__gnu_cxx::_Lock_policy)2>::operator=(std::__shared_count<(__gnu_cxx::_Lock_policy)2> const&):
/usr/include/c++/13/bits/shared_ptr_base.h:1091
   1791d:	48 89 6b 68          	mov    %rbp,0x68(%rbx)
__gnu_cxx::__atomic_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:108 (discriminator 1)
   17921:	84 c0                	test   %al,%al
   17923:	0f 85 2e fe ff ff    	jne    17757 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xc7>
__gnu_cxx::__atomic_add(int volatile*, int):
/usr/include/c++/13/ext/atomicity.h:71
   17929:	f0 83 45 08 01       	lock addl $0x1,0x8(%rbp)
   1792e:	e9 28 fe ff ff       	jmp    1775b <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xcb>
   17933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   17938:	f0 83 45 08 01       	lock addl $0x1,0x8(%rbp)
   1793d:	e9 a9 fe ff ff       	jmp    177eb <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x15b>
   17942:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
__gnu_cxx::__exchange_and_add(int volatile*, int):
/usr/include/c++/13/ext/atomicity.h:66
   17948:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1794d:	f0 0f c1 01          	lock xadd %eax,(%rcx)
__gnu_cxx::__exchange_and_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:101
   17951:	eb ba                	jmp    1790d <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x27d>
   17953:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
__gnu_cxx::__exchange_and_add(int volatile*, int):
/usr/include/c++/13/ext/atomicity.h:66
   17958:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1795d:	f0 41 0f c1 45 00    	lock xadd %eax,0x0(%r13)
__gnu_cxx::__exchange_and_add_dispatch(int*, int):
/usr/include/c++/13/ext/atomicity.h:101
   17963:	e9 31 ff ff ff       	jmp    17899 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x209>
   17968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   1796f:	00 
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:346
   17970:	48 8b 45 00          	mov    0x0(%rbp),%rax
   17974:	48 89 ef             	mov    %rbp,%rdi
/usr/include/c++/13/bits/shared_ptr_base.h:343
   17977:	48 c7 45 08 00 00 00 	movq   $0x0,0x8(%rbp)
   1797e:	00 
/usr/include/c++/13/bits/shared_ptr_base.h:346
   1797f:	ff 50 10             	call   *0x10(%rax)
/usr/include/c++/13/bits/shared_ptr_base.h:347
   17982:	48 8b 45 00          	mov    0x0(%rbp),%rax
   17986:	48 89 ef             	mov    %rbp,%rdi
   17989:	ff 50 18             	call   *0x18(%rax)
/usr/include/c++/13/bits/shared_ptr_base.h:348
   1798c:	e9 11 ff ff ff       	jmp    178a2 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x212>
   17991:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/usr/include/c++/13/bits/shared_ptr_base.h:346
   17998:	49 8b 06             	mov    (%r14),%rax
   1799b:	4c 89 f7             	mov    %r14,%rdi
/usr/include/c++/13/bits/shared_ptr_base.h:343
   1799e:	49 c7 46 08 00 00 00 	movq   $0x0,0x8(%r14)
   179a5:	00 
/usr/include/c++/13/bits/shared_ptr_base.h:346
   179a6:	ff 50 10             	call   *0x10(%rax)
/usr/include/c++/13/bits/shared_ptr_base.h:347
   179a9:	49 8b 06             	mov    (%r14),%rax
   179ac:	4c 89 f7             	mov    %r14,%rdi
   179af:	ff 50 18             	call   *0x18(%rax)
__gnu_cxx::__is_single_threaded():
/usr/include/c++/13/ext/atomicity.h:52
   179b2:	0f b6 05 a7 4a 05 00 	movzbl 0x54aa7(%rip),%eax        # 6c460 <__libc_single_threaded@GLIBC_2.32>
   179b9:	e9 5f ff ff ff       	jmp    1791d <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x28d>
   179be:	66 90                	xchg   %ax,%ax
std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release():
/usr/include/c++/13/bits/shared_ptr_base.h:353
   179c0:	4c 89 f7             	mov    %r14,%rdi
   179c3:	e8 48 00 00 00       	call   17a10 <std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release_last_use_cold()>
   179c8:	e9 49 ff ff ff       	jmp    17916 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x286>
   179cd:	0f 1f 00             	nopl   (%rax)
   179d0:	48 89 ef             	mov    %rbp,%rdi
   179d3:	e8 38 00 00 00       	call   17a10 <std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release_last_use_cold()>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:291
   179d8:	e9 c5 fe ff ff       	jmp    178a2 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x212>
/usr/include/c++/13/bits/std_function.h:292
   179dd:	e8 ee f1 fe ff       	call   6bd0 <__stack_chk_fail@plt>
   179e2:	f3 0f 1e fa          	endbr64
std::_Function_base::~_Function_base():
/usr/include/c++/13/bits/std_function.h:243
   179e6:	49 89 c4             	mov    %rax,%r12
   179e9:	e9 12 fc fe ff       	jmp    7600 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]>
   179ee:	f3 0f 1e fa          	endbr64
   179f2:	49 89 c4             	mov    %rax,%r12
   179f5:	e9 1f fc fe ff       	jmp    7619 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x19>
   179fa:	f3 0f 1e fa          	endbr64
deallocate():
/usr/include/c++/13/bits/new_allocator.h:172
   179fe:	48 89 c3             	mov    %rax,%rbx
   17a01:	e9 5a fc fe ff       	jmp    7660 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&) [clone .cold]+0x60>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
   17a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   17a0d:	00 00 00 

