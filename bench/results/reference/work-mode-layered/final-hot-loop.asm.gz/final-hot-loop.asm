0000000000007469 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>:
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
    7469:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    746e:	e8 5d 3f 01 00       	call   1b3d0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()>
std::allocator<char>::~allocator():
/usr/include/c++/13/bits/allocator.h:184
    7473:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7478:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    747f:	00 00 
    7481:	75 08                	jne    748b <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]+0x22>
    7483:	48 89 df             	mov    %rbx,%rdi
    7486:	e8 35 fa ff ff       	call   6ec0 <_Unwind_Resume@plt>
    748b:	e8 40 f7 ff ff       	call   6bd0 <__stack_chk_fail@plt>


000000000000b550 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
    b550:	f3 0f 1e fa          	endbr64
    b554:	41 57                	push   %r15
    b556:	41 56                	push   %r14
    b558:	41 55                	push   %r13
    b55a:	41 54                	push   %r12
    b55c:	55                   	push   %rbp
    b55d:	53                   	push   %rbx
    b55e:	48 83 ec 38          	sub    $0x38,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b562:	48 8b 07             	mov    (%rdi),%rax
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b565:	4c 8b 38             	mov    (%rax),%r15
std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b568:	49 8b 87 40 15 00 00 	mov    0x1540(%r15),%rax
    b56f:	4d 8b af 38 15 00 00 	mov    0x1538(%r15),%r13
    b576:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b57b:	4c 29 e8             	sub    %r13,%rax
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 2)
    b57e:	48 83 f8 08          	cmp    $0x8,%rax
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 2)
    b582:	0f 84 c8 03 00 00    	je     b950 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x400>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1606
    b588:	4d 8b b7 08 15 00 00 	mov    0x1508(%r15),%r14
/usr/include/c++/13/bits/stl_vector.h:1935
    b58f:	49 8b af 10 15 00 00 	mov    0x1510(%r15),%rbp
_M_erase_at_end():
/usr/include/c++/13/bits/stl_vector.h:1935
    b596:	49 39 ee             	cmp    %rbp,%r14
    b599:	0f 84 e9 01 00 00    	je     b788 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x238>
/usr/include/c++/13/bits/stl_vector.h:1939
    b59f:	4d 89 b7 10 15 00 00 	mov    %r14,0x1510(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:468 (discriminator 1)
    b5a6:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
    b5ab:	0f 84 e2 01 00 00    	je     b793 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x243>
    b5b1:	4c 89 f5             	mov    %r14,%rbp
    b5b4:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
    b5b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:468 (discriminator 3)
    b5c0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b5c5:	4c 8b 28             	mov    (%rax),%r13
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b5c8:	49 8b 95 70 02 00 00 	mov    0x270(%r13),%rdx
    b5cf:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
    b5d6:	49 89 d4             	mov    %rdx,%r12
    b5d9:	49 29 c4             	sub    %rax,%r12
    b5dc:	49 c1 fc 02          	sar    $0x2,%r12
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:470 (discriminator 1)
    b5e0:	48 39 c2             	cmp    %rax,%rdx
    b5e3:	0f 84 df 00 00 00    	je     b6c8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:114
    b5e9:	49 8b 8f 18 15 00 00 	mov    0x1518(%r15),%rcx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:470
    b5f0:	31 db                	xor    %ebx,%ebx
    b5f2:	eb 21                	jmp    b615 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xc5>
    b5f4:	0f 1f 40 00          	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b5f8:	4c 89 6d 00          	mov    %r13,0x0(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b5fc:	48 83 c5 10          	add    $0x10,%rbp
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b600:	66 0f d6 4d f8       	movq   %xmm1,-0x8(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b605:	49 89 af 10 15 00 00 	mov    %rbp,0x1510(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:470 (discriminator 1)
    b60c:	4c 39 e3             	cmp    %r12,%rbx
    b60f:	0f 83 b3 00 00 00    	jae    b6c8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
    b615:	66 0f 6e c3          	movd   %ebx,%xmm0
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:471
    b619:	48 83 c3 01          	add    $0x1,%rbx
unsigned long const& std::min<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:238
    b61d:	49 39 dc             	cmp    %rbx,%r12
    b620:	48 89 da             	mov    %rbx,%rdx
    b623:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b627:	49 0f 46 d4          	cmovbe %r12,%rdx
    b62b:	66 0f 6e d2          	movd   %edx,%xmm2
    b62f:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:114
    b633:	48 39 cd             	cmp    %rcx,%rbp
    b636:	75 c0                	jne    b5f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xa8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b638:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    b63f:	ff ff 07 
/usr/include/c++/13/bits/stl_vector.h:993
    b642:	48 89 ee             	mov    %rbp,%rsi
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b645:	4c 29 f6             	sub    %r14,%rsi
    b648:	48 89 f1             	mov    %rsi,%rcx
    b64b:	48 c1 f9 04          	sar    $0x4,%rcx
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b64f:	48 39 c1             	cmp    %rax,%rcx
    b652:	0f 84 89 04 00 00    	je     bae1 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x591>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
    b658:	4c 39 f5             	cmp    %r14,%rbp
    b65b:	0f 84 0f 02 00 00    	je     b870 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x320>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
    b661:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b665:	48 39 c8             	cmp    %rcx,%rax
    b668:	0f 82 5a 02 00 00    	jb     b8c8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x378>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:378
    b66e:	31 c9                	xor    %ecx,%ecx
_M_allocate():
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
    b670:	45 31 db             	xor    %r11d,%r11d
/usr/include/c++/13/bits/stl_vector.h:381
    b673:	48 85 c0             	test   %rax,%rax
    b676:	0f 85 f1 03 00 00    	jne    ba6d <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x51d>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:468
    b67c:	49 8d 04 33          	lea    (%r11,%rsi,1),%rax
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:483
    b680:	49 8d 6c 33 10       	lea    0x10(%r11,%rsi,1),%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b685:	4c 89 28             	mov    %r13,(%rax)
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b688:	89 50 0c             	mov    %edx,0xc(%rax)
    b68b:	66 0f 7e 40 08       	movd   %xmm0,0x8(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b690:	48 85 f6             	test   %rsi,%rsi
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b693:	0f 8f 8f 01 00 00    	jg     b828 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2d8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:389
    b699:	4d 85 f6             	test   %r14,%r14
_M_deallocate():
/usr/include/c++/13/bits/stl_vector.h:389
    b69c:	0f 85 9e 02 00 00    	jne    b940 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3f0>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:521
    b6a2:	4d 89 9f 08 15 00 00 	mov    %r11,0x1508(%r15)
/usr/include/c++/13/bits/vector.tcc:523
    b6a9:	4d 89 de             	mov    %r11,%r14
/usr/include/c++/13/bits/vector.tcc:522
    b6ac:	49 89 af 10 15 00 00 	mov    %rbp,0x1510(%r15)
/usr/include/c++/13/bits/vector.tcc:523
    b6b3:	49 89 8f 18 15 00 00 	mov    %rcx,0x1518(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:470 (discriminator 1)
    b6ba:	4c 39 e3             	cmp    %r12,%rbx
    b6bd:	0f 82 52 ff ff ff    	jb     b615 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xc5>
    b6c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:468 (discriminator 1)
    b6c8:	48 83 44 24 08 08    	addq   $0x8,0x8(%rsp)
    b6ce:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b6d3:	48 39 44 24 28       	cmp    %rax,0x28(%rsp)
    b6d8:	0f 85 e2 fe ff ff    	jne    b5c0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x70>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:993
    b6de:	4c 29 f5             	sub    %r14,%rbp
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:473 (discriminator 1)
    b6e1:	48 83 fd 30          	cmp    $0x30,%rbp
    b6e5:	0f 86 a8 00 00 00    	jbe    b793 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x243>
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b6eb:	48 c1 fd 04          	sar    $0x4,%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b6ef:	4d 89 f1             	mov    %r14,%r9
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26
    b6f2:	45 31 c0             	xor    %r8d,%r8d
    b6f5:	0f 1f 00             	nopl   (%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484
    b6f8:	49 8b 01             	mov    (%r9),%rax
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485
    b6fb:	45 8b 51 08          	mov    0x8(%r9),%r10d
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485 (discriminator 2)
    b6ff:	41 8b 79 0c          	mov    0xc(%r9),%edi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b703:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b707:	48 8b 48 70          	mov    0x70(%rax),%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485 (discriminator 2)
    b70b:	41 39 fa             	cmp    %edi,%r10d
    b70e:	73 59                	jae    b769 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x219>
    b710:	89 fb                	mov    %edi,%ebx
    b712:	45 89 d3             	mov    %r10d,%r11d
    b715:	44 29 d3             	sub    %r10d,%ebx
    b718:	8d 43 ff             	lea    -0x1(%rbx),%eax
    b71b:	83 f8 01             	cmp    $0x1,%eax
    b71e:	76 1a                	jbe    b73a <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1ea>
    b720:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b727:	00 
    b728:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    b72c:	4c 8d 64 01 08       	lea    0x8(%rcx,%rax,1),%r12
    b731:	4c 39 e6             	cmp    %r12,%rsi
    b734:	0f 85 9e 01 00 00    	jne    b8d8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x388>
    b73a:	83 ef 01             	sub    $0x1,%edi
    b73d:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b744:	00 
    b745:	44 29 d7             	sub    %r10d,%edi
    b748:	4a 8d 7c 1f 01       	lea    0x1(%rdi,%r11,1),%rdi
    b74d:	48 c1 e7 03          	shl    $0x3,%rdi
    b751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b758:	48 8b 34 01          	mov    (%rcx,%rax,1),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b75c:	48 01 34 02          	add    %rsi,(%rdx,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485 (discriminator 2)
    b760:	48 83 c0 08          	add    $0x8,%rax
    b764:	48 39 c7             	cmp    %rax,%rdi
    b767:	75 ef                	jne    b758 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x208>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 3)
    b769:	49 83 c0 01          	add    $0x1,%r8
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b76d:	49 83 c1 10          	add    $0x10,%r9
    b771:	49 39 e8             	cmp    %rbp,%r8
    b774:	72 82                	jb     b6f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1a8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b776:	48 83 c4 38          	add    $0x38,%rsp
    b77a:	5b                   	pop    %rbx
    b77b:	5d                   	pop    %rbp
    b77c:	41 5c                	pop    %r12
    b77e:	41 5d                	pop    %r13
    b780:	41 5e                	pop    %r14
    b782:	41 5f                	pop    %r15
    b784:	c3                   	ret
    b785:	0f 1f 00             	nopl   (%rax)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:468 (discriminator 1)
    b788:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
    b78d:	0f 85 21 fe ff ff    	jne    b5b4 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x64>
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
    b793:	49 8b 87 38 15 00 00 	mov    0x1538(%r15),%rax
    b79a:	4d 8b 8f 40 15 00 00 	mov    0x1540(%r15),%r9
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:475 (discriminator 1)
    b7a1:	4c 39 c8             	cmp    %r9,%rax
    b7a4:	74 d0                	je     b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b7a6:	49 89 c0             	mov    %rax,%r8
    b7a9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    b7af:	90                   	nop
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:475 (discriminator 3)
    b7b0:	49 8b 00             	mov    (%r8),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b7b3:	4c 8b 98 70 02 00 00 	mov    0x270(%rax),%r11
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b7ba:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b7be:	48 8b 48 70          	mov    0x70(%rax),%rcx
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b7c2:	48 8b 80 68 02 00 00 	mov    0x268(%rax),%rax
    b7c9:	4c 89 de             	mov    %r11,%rsi
    b7cc:	48 29 c6             	sub    %rax,%rsi
    b7cf:	48 89 f7             	mov    %rsi,%rdi
    b7d2:	48 c1 ff 02          	sar    $0x2,%rdi
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:478 (discriminator 2)
    b7d6:	49 39 c3             	cmp    %rax,%r11
    b7d9:	74 2e                	je     b809 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b9>
    b7db:	48 83 fe 08          	cmp    $0x8,%rsi
    b7df:	0f 86 5b 02 00 00    	jbe    ba40 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4f0>
    b7e5:	4c 8d 59 08          	lea    0x8(%rcx),%r11
    b7e9:	31 c0                	xor    %eax,%eax
    b7eb:	4c 39 da             	cmp    %r11,%rdx
    b7ee:	0f 85 ec 01 00 00    	jne    b9e0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x490>
    b7f4:	0f 1f 40 00          	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b7f8:	48 8b 34 c1          	mov    (%rcx,%rax,8),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b7fc:	48 01 34 c2          	add    %rsi,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:478 (discriminator 3)
    b800:	48 83 c0 01          	add    $0x1,%rax
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:478 (discriminator 2)
    b804:	48 39 f8             	cmp    %rdi,%rax
    b807:	72 ef                	jb     b7f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2a8>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:475 (discriminator 1)
    b809:	49 83 c0 08          	add    $0x8,%r8
    b80d:	4d 39 c1             	cmp    %r8,%r9
    b810:	75 9e                	jne    b7b0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x260>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b812:	48 83 c4 38          	add    $0x38,%rsp
    b816:	5b                   	pop    %rbx
    b817:	5d                   	pop    %rbp
    b818:	41 5c                	pop    %r12
    b81a:	41 5d                	pop    %r13
    b81c:	41 5e                	pop    %r14
    b81e:	41 5f                	pop    %r15
    b820:	c3                   	ret
    b821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b828:	48 89 f2             	mov    %rsi,%rdx
    b82b:	4c 89 df             	mov    %r11,%rdi
    b82e:	4c 89 f6             	mov    %r14,%rsi
    b831:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    b836:	e8 e5 b5 ff ff       	call   6e20 <memmove@plt>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b83b:	49 8b b7 18 15 00 00 	mov    0x1518(%r15),%rsi
    b842:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b847:	49 89 c3             	mov    %rax,%r11
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b84a:	4c 29 f6             	sub    %r14,%rsi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:172
    b84d:	4c 89 f7             	mov    %r14,%rdi
deallocate():
/usr/include/c++/13/bits/new_allocator.h:172
    b850:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    b855:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    b85a:	e8 11 b3 ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
    b85f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    b864:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    b869:	e9 34 fe ff ff       	jmp    b6a2 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x152>
    b86e:	66 90                	xchg   %ax,%ax
    b870:	48 83 c1 01          	add    $0x1,%rcx
    b874:	72 52                	jb     b8c8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x378>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b876:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    b87d:	ff ff 07 
    b880:	48 39 c1             	cmp    %rax,%rcx
    b883:	48 0f 47 c8          	cmova  %rax,%rcx
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:151
    b887:	48 c1 e1 04          	shl    $0x4,%rcx
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b88b:	48 89 cd             	mov    %rcx,%rbp
    b88e:	48 89 ef             	mov    %rbp,%rdi
    b891:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b896:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    b89b:	66 0f 7e 44 24 10    	movd   %xmm0,0x10(%rsp)
    b8a1:	e8 ba b2 ff ff       	call   6b60 <operator new(unsigned long)@plt>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:523
    b8a6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b8ab:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
    b8b0:	66 0f 6e 44 24 10    	movd   0x10(%rsp),%xmm0
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b8b6:	49 89 c3             	mov    %rax,%r11
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:523
    b8b9:	48 8d 0c 28          	lea    (%rax,%rbp,1),%rcx
_M_allocate():
/usr/include/c++/13/bits/vector.tcc:523
    b8bd:	e9 ba fd ff ff       	jmp    b67c <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x12c>
    b8c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
_M_check_len():
/usr/include/c++/13/bits/vector.tcc:523
    b8c8:	48 bd f0 ff ff ff ff 	movabs $0x7ffffffffffffff0,%rbp
    b8cf:	ff ff 7f 
    b8d2:	eb ba                	jmp    b88e <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x33e>
    b8d4:	0f 1f 40 00          	nopl   0x0(%rax)
    b8d8:	41 89 db             	mov    %ebx,%r11d
    b8db:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485 (discriminator 2)
    b8df:	31 c0                	xor    %eax,%eax
    b8e1:	41 d1 eb             	shr    $1,%r11d
    b8e4:	49 c1 e3 04          	shl    $0x4,%r11
    b8e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b8ef:	00 
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b8f0:	f3 0f 6f 04 06       	movdqu (%rsi,%rax,1),%xmm0
    b8f5:	f3 0f 6f 1c 07       	movdqu (%rdi,%rax,1),%xmm3
    b8fa:	66 0f d4 c3          	paddq  %xmm3,%xmm0
    b8fe:	0f 11 04 06          	movups %xmm0,(%rsi,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:485 (discriminator 2)
    b902:	48 83 c0 10          	add    $0x10,%rax
    b906:	4c 39 d8             	cmp    %r11,%rax
    b909:	75 e5                	jne    b8f0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3a0>
    b90b:	89 d8                	mov    %ebx,%eax
    b90d:	83 e0 fe             	and    $0xfffffffe,%eax
    b910:	44 01 d0             	add    %r10d,%eax
    b913:	83 e3 01             	and    $0x1,%ebx
    b916:	0f 84 4d fe ff ff    	je     b769 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x219>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 3)
    b91c:	49 83 c0 01          	add    $0x1,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b920:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b924:	49 83 c1 10          	add    $0x10,%r9
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b928:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b92c:	49 39 e8             	cmp    %rbp,%r8
    b92f:	0f 82 c3 fd ff ff    	jb     b6f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1a8>
    b935:	e9 3c fe ff ff       	jmp    b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b93a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b940:	49 8b b7 18 15 00 00 	mov    0x1518(%r15),%rsi
    b947:	4c 29 f6             	sub    %r14,%rsi
    b94a:	e9 fe fe ff ff       	jmp    b84d <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2fd>
    b94f:	90                   	nop
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:448 (discriminator 2)
    b950:	49 8b 4d 00          	mov    0x0(%r13),%rcx
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b954:	48 8b 91 70 02 00 00 	mov    0x270(%rcx),%rdx
    b95b:	48 2b 91 68 02 00 00 	sub    0x268(%rcx),%rdx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:450
    b962:	48 89 d6             	mov    %rdx,%rsi
    b965:	48 c1 fe 02          	sar    $0x2,%rsi
    b969:	0f 84 07 fe ff ff    	je     b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b96f:	48 8b 41 68          	mov    0x68(%rcx),%rax
    b973:	48 8b 49 70          	mov    0x70(%rcx),%rcx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    b977:	48 83 fa 0c          	cmp    $0xc,%rdx
    b97b:	77 39                	ja     b9b6 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x466>
    b97d:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    b981:	48 83 fa 01          	cmp    $0x1,%rdx
    b985:	0f 86 4f 01 00 00    	jbe    bada <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x58a>
    b98b:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    b98f:	31 d2                	xor    %edx,%edx
    b991:	48 39 f8             	cmp    %rdi,%rax
    b994:	0f 85 ad 00 00 00    	jne    ba47 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4f7>
    b99a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9a0:	48 8b 3c d1          	mov    (%rcx,%rdx,8),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9a4:	48 01 3c d0          	add    %rdi,(%rax,%rdx,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:455 (discriminator 3)
    b9a8:	48 83 c2 01          	add    $0x1,%rdx
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:455 (discriminator 2)
    b9ac:	48 39 d6             	cmp    %rdx,%rsi
    b9af:	75 ef                	jne    b9a0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x450>
    b9b1:	e9 c0 fd ff ff       	jmp    b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b9b6:	48 8d 79 08          	lea    0x8(%rcx),%rdi
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    b9ba:	31 d2                	xor    %edx,%edx
    b9bc:	48 39 f8             	cmp    %rdi,%rax
    b9bf:	0f 85 c5 00 00 00    	jne    ba8a <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x53a>
    b9c5:	0f 1f 00             	nopl   (%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9c8:	48 8b 3c d1          	mov    (%rcx,%rdx,8),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9cc:	48 01 3c d0          	add    %rdi,(%rax,%rdx,8)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 3)
    b9d0:	48 83 c2 01          	add    $0x1,%rdx
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b9d4:	48 39 d6             	cmp    %rdx,%rsi
    b9d7:	75 ef                	jne    b9c8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x478>
    b9d9:	e9 98 fd ff ff       	jmp    b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b9de:	66 90                	xchg   %ax,%ax
    b9e0:	48 85 f6             	test   %rsi,%rsi
    b9e3:	49 0f 44 fa          	cmove  %r10,%rdi
    b9e7:	48 89 fe             	mov    %rdi,%rsi
    b9ea:	48 d1 ee             	shr    $1,%rsi
    b9ed:	48 c1 e6 04          	shl    $0x4,%rsi
    b9f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9f8:	f3 0f 6f 04 02       	movdqu (%rdx,%rax,1),%xmm0
    b9fd:	f3 0f 6f 24 01       	movdqu (%rcx,%rax,1),%xmm4
    ba02:	66 0f d4 c4          	paddq  %xmm4,%xmm0
    ba06:	0f 11 04 02          	movups %xmm0,(%rdx,%rax,1)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:478 (discriminator 2)
    ba0a:	48 83 c0 10          	add    $0x10,%rax
    ba0e:	48 39 c6             	cmp    %rax,%rsi
    ba11:	75 e5                	jne    b9f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4a8>
    ba13:	48 89 f8             	mov    %rdi,%rax
    ba16:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    ba1a:	83 e7 01             	and    $0x1,%edi
    ba1d:	0f 84 e6 fd ff ff    	je     b809 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b9>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:475 (discriminator 1)
    ba23:	49 83 c0 08          	add    $0x8,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    ba27:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
    ba2b:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:475 (discriminator 1)
    ba2f:	4d 39 c1             	cmp    %r8,%r9
    ba32:	0f 85 78 fd ff ff    	jne    b7b0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x260>
    ba38:	e9 d5 fd ff ff       	jmp    b812 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c2>
    ba3d:	0f 1f 00             	nopl   (%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:478 (discriminator 2)
    ba40:	31 c0                	xor    %eax,%eax
    ba42:	e9 b1 fd ff ff       	jmp    b7f8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2a8>
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    ba47:	f3 0f 6f 31          	movdqu (%rcx),%xmm6
    ba4b:	f3 0f 6f 00          	movdqu (%rax),%xmm0
    ba4f:	66 0f d4 c6          	paddq  %xmm6,%xmm0
    ba53:	0f 11 00             	movups %xmm0,(%rax)
    ba56:	48 8b 51 10          	mov    0x10(%rcx),%rdx
    ba5a:	48 01 50 10          	add    %rdx,0x10(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    ba5e:	48 83 c4 38          	add    $0x38,%rsp
    ba62:	5b                   	pop    %rbx
    ba63:	5d                   	pop    %rbp
    ba64:	41 5c                	pop    %r12
    ba66:	41 5d                	pop    %r13
    ba68:	41 5e                	pop    %r14
    ba6a:	41 5f                	pop    %r15
    ba6c:	c3                   	ret
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    ba6d:	48 b9 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rcx
    ba74:	ff ff 07 
    ba77:	48 39 c8             	cmp    %rcx,%rax
    ba7a:	48 0f 47 c1          	cmova  %rcx,%rax
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    ba7e:	48 c1 e0 04          	shl    $0x4,%rax
    ba82:	48 89 c5             	mov    %rax,%rbp
    ba85:	e9 04 fe ff ff       	jmp    b88e <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x33e>
    ba8a:	48 89 f7             	mov    %rsi,%rdi
    ba8d:	48 d1 ef             	shr    $1,%rdi
    ba90:	48 c1 e7 04          	shl    $0x4,%rdi
    ba94:	0f 1f 40 00          	nopl   0x0(%rax)
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    ba98:	f3 0f 6f 04 11       	movdqu (%rcx,%rdx,1),%xmm0
    ba9d:	f3 0f 6f 2c 10       	movdqu (%rax,%rdx,1),%xmm5
    baa2:	66 0f d4 c5          	paddq  %xmm5,%xmm0
    baa6:	0f 11 04 10          	movups %xmm0,(%rax,%rdx,1)
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    baaa:	48 83 c2 10          	add    $0x10,%rdx
    baae:	48 39 d7             	cmp    %rdx,%rdi
    bab1:	75 e5                	jne    ba98 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x548>
    bab3:	48 89 f2             	mov    %rsi,%rdx
    bab6:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    baba:	83 e6 01             	and    $0x1,%esi
    babd:	0f 84 b3 fc ff ff    	je     b776 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    bac3:	48 8b 0c d1          	mov    (%rcx,%rdx,8),%rcx
    bac7:	48 01 0c d0          	add    %rcx,(%rax,%rdx,8)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    bacb:	48 83 c4 38          	add    $0x38,%rsp
    bacf:	5b                   	pop    %rbx
    bad0:	5d                   	pop    %rbp
    bad1:	41 5c                	pop    %r12
    bad3:	41 5d                	pop    %r13
    bad5:	41 5e                	pop    %r14
    bad7:	41 5f                	pop    %r15
    bad9:	c3                   	ret
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    bada:	31 d2                	xor    %edx,%edx
    badc:	e9 bf fe ff ff       	jmp    b9a0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x450>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1899
    bae1:	48 8d 3d 1c 05 05 00 	lea    0x5051c(%rip),%rdi        # 5c004 <_IO_stdin_used+0x4>
    bae8:	e8 d3 ae ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1899
    baed:	90                   	nop
    baee:	66 90                	xchg   %ax,%ax


0000000000012900 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)>:
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:288
   12900:	f3 0f 1e fa          	endbr64
   12904:	41 57                	push   %r15
   12906:	41 56                	push   %r14
   12908:	41 55                	push   %r13
   1290a:	41 54                	push   %r12
   1290c:	55                   	push   %rbp
   1290d:	48 89 f5             	mov    %rsi,%rbp
   12910:	53                   	push   %rbx
   12911:	48 83 ec 48          	sub    $0x48,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   12915:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1291c:	00 00 
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   1291e:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   12923:	48 8b 07             	mov    (%rdi),%rax
   12926:	48 8b 00             	mov    (%rax),%rax
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
   12929:	48 8b 88 38 15 00 00 	mov    0x1538(%rax),%rcx
   12930:	4c 8b 90 40 15 00 00 	mov    0x1540(%rax),%r10
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12937:	4c 39 d1             	cmp    %r10,%rcx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   1293a:	0f 84 03 04 00 00    	je     12d43 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x443>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   12940:	31 d2                	xor    %edx,%edx
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   12942:	eb 14                	jmp    12958 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12944:	48 83 c1 08          	add    $0x8,%rcx
   12948:	49 39 ca             	cmp    %rcx,%r10
   1294b:	0f 84 97 00 00 00    	je     129e8 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xe8>
   12951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 3)
   12958:	48 8b 01             	mov    (%rcx),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   1295b:	4c 8b 88 70 02 00 00 	mov    0x270(%rax),%r9
   12962:	4c 8b 80 68 02 00 00 	mov    0x268(%rax),%r8
   12969:	4c 89 ce             	mov    %r9,%rsi
   1296c:	4c 29 c6             	sub    %r8,%rsi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:197
   1296f:	49 89 f3             	mov    %rsi,%r11
   12972:	49 c1 fb 02          	sar    $0x2,%r11
   12976:	74 cc                	je     12944 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
   12978:	48 8b 78 68          	mov    0x68(%rax),%rdi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   1297c:	4d 39 c1             	cmp    %r8,%r9
   1297f:	74 c3                	je     12944 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
   12981:	48 83 fe 04          	cmp    $0x4,%rsi
   12985:	0f 84 38 01 00 00    	je     12ac3 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1c3>
   1298b:	4c 89 de             	mov    %r11,%rsi
   1298e:	48 89 f8             	mov    %rdi,%rax
   12991:	66 0f ef c0          	pxor   %xmm0,%xmm0
   12995:	48 d1 ee             	shr    $1,%rsi
   12998:	48 c1 e6 04          	shl    $0x4,%rsi
   1299c:	48 01 fe             	add    %rdi,%rsi
   1299f:	90                   	nop
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   129a0:	f3 0f 6f 10          	movdqu (%rax),%xmm2
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   129a4:	48 83 c0 10          	add    $0x10,%rax
   129a8:	66 0f d4 c2          	paddq  %xmm2,%xmm0
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   129ac:	48 39 c6             	cmp    %rax,%rsi
   129af:	75 ef                	jne    129a0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xa0>
   129b1:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   129b5:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
   129ba:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   129be:	66 48 0f 7e c0       	movq   %xmm0,%rax
   129c3:	48 01 c2             	add    %rax,%rdx
   129c6:	4c 89 d8             	mov    %r11,%rax
   129c9:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   129cd:	41 83 e3 01          	and    $0x1,%r11d
   129d1:	0f 84 6d ff ff ff    	je     12944 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   129d7:	48 83 c1 08          	add    $0x8,%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   129db:	48 03 14 c7          	add    (%rdi,%rax,8),%rdx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   129df:	49 39 ca             	cmp    %rcx,%r10
   129e2:	0f 85 70 ff ff ff    	jne    12958 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:80
   129e8:	48 85 d2             	test   %rdx,%rdx
   129eb:	0f 88 af 00 00 00    	js     12aa0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1a0>
   129f1:	66 0f ef e4          	pxor   %xmm4,%xmm4
   129f5:	f2 48 0f 2a e2       	cvtsi2sd %rdx,%xmm4
   129fa:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   129ff:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   12a04:	c6 44 24 28 00       	movb   $0x0,0x28(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12a09:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   12a10:	73 75 6d 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   12a13:	48 8b 9d 50 01 00 00 	mov    0x150(%rbp),%rbx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   12a1a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12a1f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12a24:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   12a2b:	00 00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   12a2d:	48 3b 9d 58 01 00 00 	cmp    0x158(%rbp),%rbx
   12a34:	0f 84 90 00 00 00    	je     12aca <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1ca>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12a3a:	48 8d 53 10          	lea    0x10(%rbx),%rdx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12a3e:	48 89 13             	mov    %rdx,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12a41:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12a46:	4c 39 e0             	cmp    %r12,%rax
   12a49:	0f 84 e1 02 00 00    	je     12d30 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x430>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12a4f:	48 89 03             	mov    %rax,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   12a52:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   12a57:	48 89 43 10          	mov    %rax,0x10(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12a5b:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12a60:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
   12a67:	00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12a68:	f2 0f 11 5b 20       	movsd  %xmm3,0x20(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:119
   12a6d:	48 83 85 50 01 00 00 	addq   $0x28,0x150(%rbp)
   12a74:	28 
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   12a75:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   12a7a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   12a81:	00 00 
   12a83:	0f 85 8f 03 00 00    	jne    12e18 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   12a89:	48 83 c4 48          	add    $0x48,%rsp
   12a8d:	5b                   	pop    %rbx
   12a8e:	5d                   	pop    %rbp
   12a8f:	41 5c                	pop    %r12
   12a91:	41 5d                	pop    %r13
   12a93:	41 5e                	pop    %r14
   12a95:	41 5f                	pop    %r15
   12a97:	c3                   	ret
   12a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   12a9f:	00 
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:80
   12aa0:	48 89 d0             	mov    %rdx,%rax
   12aa3:	83 e2 01             	and    $0x1,%edx
   12aa6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   12aaa:	48 d1 e8             	shr    $1,%rax
   12aad:	48 09 d0             	or     %rdx,%rax
   12ab0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   12ab5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   12ab9:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
   12abe:	e9 3c ff ff ff       	jmp    129ff <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199
   12ac3:	31 c0                	xor    %eax,%eax
   12ac5:	e9 0d ff ff ff       	jmp    129d7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xd7>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:445
   12aca:	4c 8b ad 48 01 00 00 	mov    0x148(%rbp),%r13
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   12ad1:	49 89 de             	mov    %rbx,%r14
   12ad4:	48 ba cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rdx
   12adb:	cc cc cc 
   12ade:	4d 29 ee             	sub    %r13,%r14
   12ae1:	4c 89 f0             	mov    %r14,%rax
   12ae4:	48 c1 f8 03          	sar    $0x3,%rax
   12ae8:	48 0f af c2          	imul   %rdx,%rax
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
   12aec:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   12af3:	33 33 03 
   12af6:	48 39 d0             	cmp    %rdx,%rax
   12af9:	0f 84 1e 03 00 00    	je     12e1d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x51d>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
   12aff:	4c 39 eb             	cmp    %r13,%rbx
   12b02:	74 6c                	je     12b70 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x270>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
   12b04:	48 8d 14 00          	lea    (%rax,%rax,1),%rdx
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12b08:	48 39 c2             	cmp    %rax,%rdx
   12b0b:	0f 82 3f 02 00 00    	jb     12d50 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381
   12b11:	48 85 d2             	test   %rdx,%rdx
   12b14:	0f 85 e4 02 00 00    	jne    12dfe <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4fe>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12b1a:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12b1e:	41 bf 28 00 00 00    	mov    $0x28,%r15d
   12b24:	ba 08 00 00 00       	mov    $0x8,%edx
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
   12b29:	45 31 c0             	xor    %r8d,%r8d
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12b2c:	49 89 0e             	mov    %rcx,(%r14)
   12b2f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   12b36:	00 00 
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   12b38:	48 8d 42 01          	lea    0x1(%rdx),%rax
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12b3c:	83 f8 08             	cmp    $0x8,%eax
   12b3f:	0f 83 1a 02 00 00    	jae    12d5f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x45f>
   12b45:	a8 04                	test   $0x4,%al
   12b47:	0f 85 8f 02 00 00    	jne    12ddc <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4dc>
   12b4d:	85 c0                	test   %eax,%eax
   12b4f:	74 7c                	je     12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12b51:	0f b6 74 24 20       	movzbl 0x20(%rsp),%esi
   12b56:	40 88 31             	mov    %sil,(%rcx)
   12b59:	a8 02                	test   $0x2,%al
   12b5b:	74 70                	je     12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12b5d:	89 c0                	mov    %eax,%eax
   12b5f:	41 0f b7 74 04 fe    	movzwl -0x2(%r12,%rax,1),%esi
   12b65:	66 89 74 01 fe       	mov    %si,-0x2(%rcx,%rax,1)
   12b6a:	eb 61                	jmp    12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12b6c:	0f 1f 40 00          	nopl   0x0(%rax)
   12b70:	48 83 c0 01          	add    $0x1,%rax
   12b74:	0f 82 d6 01 00 00    	jb     12d50 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12b7a:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   12b81:	33 33 03 
   12b84:	48 39 d0             	cmp    %rdx,%rax
   12b87:	48 0f 47 c2          	cmova  %rdx,%rax
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   12b8b:	4c 8d 3c 80          	lea    (%rax,%rax,4),%r15
   12b8f:	49 c1 e7 03          	shl    $0x3,%r15
   12b93:	4c 89 ff             	mov    %r15,%rdi
   12b96:	e8 c5 3f ff ff       	call   6b60 <operator new(unsigned long)@plt>
   12b9b:	49 89 c0             	mov    %rax,%r8
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12b9e:	4a 8d 04 38          	lea    (%rax,%r15,1),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:266
   12ba2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12ba7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12bac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   12bb1:	4d 8d 78 28          	lea    0x28(%r8),%r15
/usr/include/c++/13/bits/vector.tcc:468
   12bb5:	4d 01 c6             	add    %r8,%r14
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12bb8:	4c 39 e0             	cmp    %r12,%rax
   12bbb:	0f 84 31 02 00 00    	je     12df2 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4f2>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12bc1:	49 89 06             	mov    %rax,(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   12bc4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   12bc9:	49 89 46 10          	mov    %rax,0x10(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12bcd:	f2 0f 10 2c 24       	movsd  (%rsp),%xmm5
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12bd2:	49 89 56 08          	mov    %rdx,0x8(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12bd6:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12bdb:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   12be2:	00 00 
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   12be4:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12be9:	f2 41 0f 11 6e 20    	movsd  %xmm5,0x20(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   12bef:	4c 39 eb             	cmp    %r13,%rbx
   12bf2:	0f 84 8f 00 00 00    	je     12c87 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x387>
   12bf8:	4c 89 e8             	mov    %r13,%rax
/usr/include/c++/13/bits/stl_uninitialized.h:1103
   12bfb:	4c 89 c2             	mov    %r8,%rdx
   12bfe:	eb 2a                	jmp    12c2a <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x32a>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12c00:	48 89 0a             	mov    %rcx,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   12c03:	48 8b 48 10          	mov    0x10(%rax),%rcx
   12c07:	48 89 4a 10          	mov    %rcx,0x10(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12c0b:	48 8b 48 08          	mov    0x8(%rax),%rcx
   12c0f:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   12c13:	f2 0f 10 40 20       	movsd  0x20(%rax),%xmm0
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 2)
   12c18:	48 83 c0 28          	add    $0x28,%rax
   12c1c:	48 83 c2 28          	add    $0x28,%rdx
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   12c20:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   12c25:	48 39 c3             	cmp    %rax,%rbx
   12c28:	74 4d                	je     12c77 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x377>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12c2a:	48 8d 72 10          	lea    0x10(%rdx),%rsi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:241
   12c2e:	48 8d 78 10          	lea    0x10(%rax),%rdi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12c32:	48 89 32             	mov    %rsi,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12c35:	48 8b 08             	mov    (%rax),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12c38:	48 39 f9             	cmp    %rdi,%rcx
   12c3b:	75 c3                	jne    12c00 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x300>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   12c3d:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12c41:	49 8d 79 01          	lea    0x1(%r9),%rdi
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12c45:	83 ff 08             	cmp    $0x8,%edi
   12c48:	0f 83 97 00 00 00    	jae    12ce5 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x3e5>
   12c4e:	40 f6 c7 04          	test   $0x4,%dil
   12c52:	0f 85 56 01 00 00    	jne    12dae <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4ae>
   12c58:	85 ff                	test   %edi,%edi
   12c5a:	74 15                	je     12c71 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12c5c:	44 0f b6 09          	movzbl (%rcx),%r9d
   12c60:	44 88 0e             	mov    %r9b,(%rsi)
   12c63:	40 f6 c7 02          	test   $0x2,%dil
   12c67:	0f 85 5a 01 00 00    	jne    12dc7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4c7>
   12c6d:	4c 8b 48 08          	mov    0x8(%rax),%r9
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12c71:	4c 89 4a 08          	mov    %r9,0x8(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_set_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:254
   12c75:	eb 9c                	jmp    12c13 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x313>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   12c77:	48 8d 43 d8          	lea    -0x28(%rbx),%rax
   12c7b:	4c 29 e8             	sub    %r13,%rax
   12c7e:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   12c82:	4d 8d 7c 00 50       	lea    0x50(%r8,%rax,1),%r15
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/stl_vector.h:389
   12c87:	4d 85 ed             	test   %r13,%r13
   12c8a:	0f 84 a9 01 00 00    	je     12e39 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x539>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   12c90:	48 8b b5 58 01 00 00 	mov    0x158(%rbp),%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12c97:	4c 89 ef             	mov    %r13,%rdi
   12c9a:	4c 89 04 24          	mov    %r8,(%rsp)
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   12c9e:	4c 29 ee             	sub    %r13,%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12ca1:	e8 ca 3e ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   12ca6:	4c 8b 04 24          	mov    (%rsp),%r8
/usr/include/c++/13/bits/vector.tcc:523
   12caa:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:522
   12caf:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12cb6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   12cbb:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   12cc2:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12cc9:	4c 39 e7             	cmp    %r12,%rdi
   12ccc:	0f 84 a3 fd ff ff    	je     12a75 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_destroy(unsigned long):
/usr/include/c++/13/bits/basic_string.h:289
   12cd2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   12cd7:	48 8d 70 01          	lea    0x1(%rax),%rsi
std::__new_allocator<char>::deallocate(char*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12cdb:	e8 90 3e ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:291
   12ce0:	e9 90 fd ff ff       	jmp    12a75 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12ce5:	4c 8b 09             	mov    (%rcx),%r9
   12ce8:	4c 89 0e             	mov    %r9,(%rsi)
   12ceb:	41 89 f9             	mov    %edi,%r9d
   12cee:	4e 8b 54 09 f8       	mov    -0x8(%rcx,%r9,1),%r10
   12cf3:	4e 89 54 0e f8       	mov    %r10,-0x8(%rsi,%r9,1)
   12cf8:	4c 8d 4a 18          	lea    0x18(%rdx),%r9
   12cfc:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
   12d00:	4c 29 ce             	sub    %r9,%rsi
   12d03:	01 f7                	add    %esi,%edi
   12d05:	48 29 f1             	sub    %rsi,%rcx
   12d08:	83 e7 f8             	and    $0xfffffff8,%edi
   12d0b:	83 ff 08             	cmp    $0x8,%edi
   12d0e:	0f 82 59 ff ff ff    	jb     12c6d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   12d14:	83 e7 f8             	and    $0xfffffff8,%edi
   12d17:	31 f6                	xor    %esi,%esi
   12d19:	41 89 f2             	mov    %esi,%r10d
   12d1c:	83 c6 08             	add    $0x8,%esi
   12d1f:	4e 8b 1c 11          	mov    (%rcx,%r10,1),%r11
   12d23:	4f 89 1c 11          	mov    %r11,(%r9,%r10,1)
   12d27:	39 fe                	cmp    %edi,%esi
   12d29:	72 ee                	jb     12d19 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x419>
   12d2b:	e9 3d ff ff ff       	jmp    12c6d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   12d30:	48 8b 08             	mov    (%rax),%rcx
   12d33:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   12d37:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   12d3b:	88 42 08             	mov    %al,0x8(%rdx)
   12d3e:	e9 18 fd ff ff       	jmp    12a5b <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x15b>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12d43:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   12d4a:	00 
   12d4b:	e9 af fc ff ff       	jmp    129ff <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12d50:	49 bf f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r15
   12d57:	ff ff 7f 
   12d5a:	e9 34 fe ff ff       	jmp    12b93 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12d5f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   12d64:	48 89 31             	mov    %rsi,(%rcx)
   12d67:	89 c6                	mov    %eax,%esi
   12d69:	49 8b 7c 34 f8       	mov    -0x8(%r12,%rsi,1),%rdi
   12d6e:	48 89 7c 31 f8       	mov    %rdi,-0x8(%rcx,%rsi,1)
   12d73:	48 8d 71 08          	lea    0x8(%rcx),%rsi
   12d77:	4c 89 e7             	mov    %r12,%rdi
   12d7a:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   12d7e:	48 29 f1             	sub    %rsi,%rcx
   12d81:	01 c8                	add    %ecx,%eax
   12d83:	48 29 cf             	sub    %rcx,%rdi
   12d86:	83 e0 f8             	and    $0xfffffff8,%eax
   12d89:	83 f8 08             	cmp    $0x8,%eax
   12d8c:	0f 82 3b fe ff ff    	jb     12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12d92:	83 e0 f8             	and    $0xfffffff8,%eax
   12d95:	31 c9                	xor    %ecx,%ecx
   12d97:	41 89 c9             	mov    %ecx,%r9d
   12d9a:	83 c1 08             	add    $0x8,%ecx
   12d9d:	4e 8b 14 0f          	mov    (%rdi,%r9,1),%r10
   12da1:	4e 89 14 0e          	mov    %r10,(%rsi,%r9,1)
   12da5:	39 c1                	cmp    %eax,%ecx
   12da7:	72 ee                	jb     12d97 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x497>
   12da9:	e9 1f fe ff ff       	jmp    12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12dae:	44 8b 09             	mov    (%rcx),%r9d
   12db1:	89 ff                	mov    %edi,%edi
   12db3:	44 89 0e             	mov    %r9d,(%rsi)
   12db6:	8b 4c 39 fc          	mov    -0x4(%rcx,%rdi,1),%ecx
   12dba:	89 4c 3e fc          	mov    %ecx,-0x4(%rsi,%rdi,1)
   12dbe:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12dc2:	e9 aa fe ff ff       	jmp    12c71 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12dc7:	89 ff                	mov    %edi,%edi
   12dc9:	0f b7 4c 39 fe       	movzwl -0x2(%rcx,%rdi,1),%ecx
   12dce:	66 89 4c 3e fe       	mov    %cx,-0x2(%rsi,%rdi,1)
   12dd3:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12dd7:	e9 95 fe ff ff       	jmp    12c71 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12ddc:	8b 74 24 20          	mov    0x20(%rsp),%esi
   12de0:	89 c0                	mov    %eax,%eax
   12de2:	89 31                	mov    %esi,(%rcx)
   12de4:	41 8b 74 04 fc       	mov    -0x4(%r12,%rax,1),%esi
   12de9:	89 74 01 fc          	mov    %esi,-0x4(%rcx,%rax,1)
   12ded:	e9 db fd ff ff       	jmp    12bcd <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12df2:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12df6:	49 89 0e             	mov    %rcx,(%r14)
   12df9:	e9 3a fd ff ff       	jmp    12b38 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x238>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12dfe:	48 b8 33 33 33 33 33 	movabs $0x333333333333333,%rax
   12e05:	33 33 03 
   12e08:	48 39 c2             	cmp    %rax,%rdx
   12e0b:	48 0f 47 d0          	cmova  %rax,%rdx
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   12e0f:	4c 6b fa 28          	imul   $0x28,%rdx,%r15
   12e13:	e9 7b fd ff ff       	jmp    12b93 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   12e18:	e8 b3 3d ff ff       	call   6bd0 <__stack_chk_fail@plt>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1899
   12e1d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   12e22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   12e29:	00 00 
   12e2b:	75 eb                	jne    12e18 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   12e2d:	48 8d 3d d0 91 04 00 	lea    0x491d0(%rip),%rdi        # 5c004 <_IO_stdin_used+0x4>
   12e34:	e8 87 3b ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12e39:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:521
   12e3e:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:522
   12e45:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   12e4c:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:238
   12e53:	e9 1d fc ff ff       	jmp    12a75 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
   12e58:	f3 0f 1e fa          	endbr64
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
   12e5c:	48 89 c3             	mov    %rax,%rbx
   12e5f:	e9 05 46 ff ff       	jmp    7469 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/basic_string.h:804
   12e64:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12e6b:	00 00 00 00 
   12e6f:	90                   	nop


0000000000019b20 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   19b20:	f3 0f 1e fa          	endbr64
   19b24:	53                   	push   %rbx
   19b25:	48 89 fb             	mov    %rdi,%rbx
   19b28:	48 83 ec 10          	sub    $0x10,%rsp
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19b2c:	0f b6 56 08          	movzbl 0x8(%rsi),%edx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19b30:	48 8b 36             	mov    (%rsi),%rsi
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   19b33:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   19b3a:	00 00 
   19b3c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   19b41:	31 c0                	xor    %eax,%eax
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19b43:	e8 78 ee ff ff       	call   189c0 <bench::harness::Prepared (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
   19b48:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   19b4d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   19b54:	00 00 
   19b56:	75 09                	jne    19b61 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x41>
   19b58:	48 83 c4 10          	add    $0x10,%rsp
   19b5c:	48 89 d8             	mov    %rbx,%rax
   19b5f:	5b                   	pop    %rbx
   19b60:	c3                   	ret
   19b61:	e8 6a d0 fe ff       	call   6bd0 <__stack_chk_fail@plt>
   19b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   19b6d:	00 00 00 

