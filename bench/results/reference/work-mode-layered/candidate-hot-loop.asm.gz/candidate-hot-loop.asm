0000000000007469 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>:
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
    7469:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    746e:	e8 cd 46 01 00       	call   1bb40 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()>
std::allocator<char>::~allocator():
/usr/include/c++/13/bits/allocator.h:184
    7473:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7478:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    747f:	00 00 
    7481:	75 08                	jne    748b <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]+0x22>
    7483:	48 89 df             	mov    %rbx,%rdi
    7486:	e8 35 fa ff ff       	call   6ec0 <_Unwind_Resume@plt>
    748b:	e8 40 f7 ff ff       	call   6bd0 <__stack_chk_fail@plt>


000000000000b4e0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
    b4e0:	f3 0f 1e fa          	endbr64
    b4e4:	41 57                	push   %r15
    b4e6:	41 56                	push   %r14
    b4e8:	41 55                	push   %r13
    b4ea:	41 54                	push   %r12
    b4ec:	55                   	push   %rbp
    b4ed:	53                   	push   %rbx
    b4ee:	48 83 ec 38          	sub    $0x38,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b4f2:	48 8b 07             	mov    (%rdi),%rax
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
    b4f5:	4c 8b 38             	mov    (%rax),%r15
std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b4f8:	49 8b 87 40 15 00 00 	mov    0x1540(%r15),%rax
    b4ff:	4d 8b af 38 15 00 00 	mov    0x1538(%r15),%r13
    b506:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b50b:	4c 29 e8             	sub    %r13,%rax
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 2)
    b50e:	48 83 f8 08          	cmp    $0x8,%rax
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:446 (discriminator 2)
    b512:	0f 84 c8 03 00 00    	je     b8e0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x400>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1606
    b518:	4d 8b b7 08 15 00 00 	mov    0x1508(%r15),%r14
/usr/include/c++/13/bits/stl_vector.h:1935
    b51f:	49 8b af 10 15 00 00 	mov    0x1510(%r15),%rbp
_M_erase_at_end():
/usr/include/c++/13/bits/stl_vector.h:1935
    b526:	49 39 ee             	cmp    %rbp,%r14
    b529:	0f 84 e9 01 00 00    	je     b718 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x238>
/usr/include/c++/13/bits/stl_vector.h:1939
    b52f:	4d 89 b7 10 15 00 00 	mov    %r14,0x1510(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:467 (discriminator 1)
    b536:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
    b53b:	0f 84 e2 01 00 00    	je     b723 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x243>
    b541:	4c 89 f5             	mov    %r14,%rbp
    b544:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
    b549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:467 (discriminator 3)
    b550:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b555:	4c 8b 28             	mov    (%rax),%r13
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b558:	49 8b 95 70 02 00 00 	mov    0x270(%r13),%rdx
    b55f:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
    b566:	49 89 d4             	mov    %rdx,%r12
    b569:	49 29 c4             	sub    %rax,%r12
    b56c:	49 c1 fc 02          	sar    $0x2,%r12
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:469 (discriminator 1)
    b570:	48 39 c2             	cmp    %rax,%rdx
    b573:	0f 84 df 00 00 00    	je     b658 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:114
    b579:	49 8b 8f 18 15 00 00 	mov    0x1518(%r15),%rcx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:469
    b580:	31 db                	xor    %ebx,%ebx
    b582:	eb 21                	jmp    b5a5 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xc5>
    b584:	0f 1f 40 00          	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b588:	4c 89 6d 00          	mov    %r13,0x0(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b58c:	48 83 c5 10          	add    $0x10,%rbp
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b590:	66 0f d6 4d f8       	movq   %xmm1,-0x8(%rbp)
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:119
    b595:	49 89 af 10 15 00 00 	mov    %rbp,0x1510(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:469 (discriminator 1)
    b59c:	4c 39 e3             	cmp    %r12,%rbx
    b59f:	0f 83 b3 00 00 00    	jae    b658 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
    b5a5:	66 0f 6e c3          	movd   %ebx,%xmm0
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:470
    b5a9:	48 83 c3 01          	add    $0x1,%rbx
unsigned long const& std::min<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:238
    b5ad:	49 39 dc             	cmp    %rbx,%r12
    b5b0:	48 89 da             	mov    %rbx,%rdx
    b5b3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b5b7:	49 0f 46 d4          	cmovbe %r12,%rdx
    b5bb:	66 0f 6e d2          	movd   %edx,%xmm2
    b5bf:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
emplace_back<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:114
    b5c3:	48 39 cd             	cmp    %rcx,%rbp
    b5c6:	75 c0                	jne    b588 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xa8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b5c8:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    b5cf:	ff ff 07 
/usr/include/c++/13/bits/stl_vector.h:993
    b5d2:	48 89 ee             	mov    %rbp,%rsi
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b5d5:	4c 29 f6             	sub    %r14,%rsi
    b5d8:	48 89 f1             	mov    %rsi,%rcx
    b5db:	48 c1 f9 04          	sar    $0x4,%rcx
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
    b5df:	48 39 c1             	cmp    %rax,%rcx
    b5e2:	0f 84 89 04 00 00    	je     ba71 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x591>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
    b5e8:	4c 39 f5             	cmp    %r14,%rbp
    b5eb:	0f 84 0f 02 00 00    	je     b800 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x320>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
    b5f1:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b5f5:	48 39 c8             	cmp    %rcx,%rax
    b5f8:	0f 82 5a 02 00 00    	jb     b858 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x378>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:378
    b5fe:	31 c9                	xor    %ecx,%ecx
_M_allocate():
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
    b600:	45 31 db             	xor    %r11d,%r11d
/usr/include/c++/13/bits/stl_vector.h:381
    b603:	48 85 c0             	test   %rax,%rax
    b606:	0f 85 f1 03 00 00    	jne    b9fd <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x51d>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/vector.tcc:468
    b60c:	49 8d 04 33          	lea    (%r11,%rsi,1),%rax
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:483
    b610:	49 8d 6c 33 10       	lea    0x10(%r11,%rsi,1),%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b615:	4c 89 28             	mov    %r13,(%rax)
construct_at<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_construct.h:97 (discriminator 1)
    b618:	89 50 0c             	mov    %edx,0xc(%rax)
    b61b:	66 0f 7e 40 08       	movd   %xmm0,0x8(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b620:	48 85 f6             	test   %rsi,%rsi
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1119
    b623:	0f 8f 8f 01 00 00    	jg     b7b8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2d8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:389
    b629:	4d 85 f6             	test   %r14,%r14
_M_deallocate():
/usr/include/c++/13/bits/stl_vector.h:389
    b62c:	0f 85 9e 02 00 00    	jne    b8d0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3f0>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:521
    b632:	4d 89 9f 08 15 00 00 	mov    %r11,0x1508(%r15)
/usr/include/c++/13/bits/vector.tcc:523
    b639:	4d 89 de             	mov    %r11,%r14
/usr/include/c++/13/bits/vector.tcc:522
    b63c:	49 89 af 10 15 00 00 	mov    %rbp,0x1510(%r15)
/usr/include/c++/13/bits/vector.tcc:523
    b643:	49 89 8f 18 15 00 00 	mov    %rcx,0x1518(%r15)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:469 (discriminator 1)
    b64a:	4c 39 e3             	cmp    %r12,%rbx
    b64d:	0f 82 52 ff ff ff    	jb     b5a5 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xc5>
    b653:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:467 (discriminator 1)
    b658:	48 83 44 24 08 08    	addq   $0x8,0x8(%rsp)
    b65e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b663:	48 39 44 24 28       	cmp    %rax,0x28(%rsp)
    b668:	0f 85 e2 fe ff ff    	jne    b550 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x70>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:993
    b66e:	4c 29 f5             	sub    %r14,%rbp
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:472 (discriminator 1)
    b671:	48 83 fd 30          	cmp    $0x30,%rbp
    b675:	0f 86 a8 00 00 00    	jbe    b723 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x243>
size():
/usr/include/c++/13/bits/stl_vector.h:993
    b67b:	48 c1 fd 04          	sar    $0x4,%rbp
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b67f:	4d 89 f1             	mov    %r14,%r9
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26
    b682:	45 31 c0             	xor    %r8d,%r8d
    b685:	0f 1f 00             	nopl   (%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:483
    b688:	49 8b 01             	mov    (%r9),%rax
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484
    b68b:	45 8b 51 08          	mov    0x8(%r9),%r10d
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484 (discriminator 2)
    b68f:	41 8b 79 0c          	mov    0xc(%r9),%edi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b693:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b697:	48 8b 48 70          	mov    0x70(%rax),%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484 (discriminator 2)
    b69b:	41 39 fa             	cmp    %edi,%r10d
    b69e:	73 59                	jae    b6f9 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x219>
    b6a0:	89 fb                	mov    %edi,%ebx
    b6a2:	45 89 d3             	mov    %r10d,%r11d
    b6a5:	44 29 d3             	sub    %r10d,%ebx
    b6a8:	8d 43 ff             	lea    -0x1(%rbx),%eax
    b6ab:	83 f8 01             	cmp    $0x1,%eax
    b6ae:	76 1a                	jbe    b6ca <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1ea>
    b6b0:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b6b7:	00 
    b6b8:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    b6bc:	4c 8d 64 01 08       	lea    0x8(%rcx,%rax,1),%r12
    b6c1:	4c 39 e6             	cmp    %r12,%rsi
    b6c4:	0f 85 9e 01 00 00    	jne    b868 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x388>
    b6ca:	83 ef 01             	sub    $0x1,%edi
    b6cd:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
    b6d4:	00 
    b6d5:	44 29 d7             	sub    %r10d,%edi
    b6d8:	4a 8d 7c 1f 01       	lea    0x1(%rdi,%r11,1),%rdi
    b6dd:	48 c1 e7 03          	shl    $0x3,%rdi
    b6e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b6e8:	48 8b 34 01          	mov    (%rcx,%rax,1),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b6ec:	48 01 34 02          	add    %rsi,(%rdx,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484 (discriminator 2)
    b6f0:	48 83 c0 08          	add    $0x8,%rax
    b6f4:	48 39 c7             	cmp    %rax,%rdi
    b6f7:	75 ef                	jne    b6e8 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x208>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 3)
    b6f9:	49 83 c0 01          	add    $0x1,%r8
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b6fd:	49 83 c1 10          	add    $0x10,%r9
    b701:	49 39 e8             	cmp    %rbp,%r8
    b704:	72 82                	jb     b688 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1a8>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b706:	48 83 c4 38          	add    $0x38,%rsp
    b70a:	5b                   	pop    %rbx
    b70b:	5d                   	pop    %rbp
    b70c:	41 5c                	pop    %r12
    b70e:	41 5d                	pop    %r13
    b710:	41 5e                	pop    %r14
    b712:	41 5f                	pop    %r15
    b714:	c3                   	ret
    b715:	0f 1f 00             	nopl   (%rax)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:467 (discriminator 1)
    b718:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
    b71d:	0f 85 21 fe ff ff    	jne    b544 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x64>
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
    b723:	49 8b 87 38 15 00 00 	mov    0x1538(%r15),%rax
    b72a:	4d 8b 8f 40 15 00 00 	mov    0x1540(%r15),%r9
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:474 (discriminator 1)
    b731:	4c 39 c8             	cmp    %r9,%rax
    b734:	74 d0                	je     b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b736:	49 89 c0             	mov    %rax,%r8
    b739:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    b73f:	90                   	nop
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:474 (discriminator 3)
    b740:	49 8b 00             	mov    (%r8),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b743:	4c 8b 98 70 02 00 00 	mov    0x270(%rax),%r11
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b74a:	48 8b 50 68          	mov    0x68(%rax),%rdx
    b74e:	48 8b 48 70          	mov    0x70(%rax),%rcx
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b752:	48 8b 80 68 02 00 00 	mov    0x268(%rax),%rax
    b759:	4c 89 de             	mov    %r11,%rsi
    b75c:	48 29 c6             	sub    %rax,%rsi
    b75f:	48 89 f7             	mov    %rsi,%rdi
    b762:	48 c1 ff 02          	sar    $0x2,%rdi
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:477 (discriminator 2)
    b766:	49 39 c3             	cmp    %rax,%r11
    b769:	74 2e                	je     b799 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b9>
    b76b:	48 83 fe 08          	cmp    $0x8,%rsi
    b76f:	0f 86 5b 02 00 00    	jbe    b9d0 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4f0>
    b775:	4c 8d 59 08          	lea    0x8(%rcx),%r11
    b779:	31 c0                	xor    %eax,%eax
    b77b:	4c 39 da             	cmp    %r11,%rdx
    b77e:	0f 85 ec 01 00 00    	jne    b970 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x490>
    b784:	0f 1f 40 00          	nopl   0x0(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b788:	48 8b 34 c1          	mov    (%rcx,%rax,8),%rsi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b78c:	48 01 34 c2          	add    %rsi,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:477 (discriminator 3)
    b790:	48 83 c0 01          	add    $0x1,%rax
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:477 (discriminator 2)
    b794:	48 39 f8             	cmp    %rdi,%rax
    b797:	72 ef                	jb     b788 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2a8>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:474 (discriminator 1)
    b799:	49 83 c0 08          	add    $0x8,%r8
    b79d:	4d 39 c1             	cmp    %r8,%r9
    b7a0:	75 9e                	jne    b740 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x260>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b7a2:	48 83 c4 38          	add    $0x38,%rsp
    b7a6:	5b                   	pop    %rbx
    b7a7:	5d                   	pop    %rbp
    b7a8:	41 5c                	pop    %r12
    b7aa:	41 5d                	pop    %r13
    b7ac:	41 5e                	pop    %r14
    b7ae:	41 5f                	pop    %r15
    b7b0:	c3                   	ret
    b7b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b7b8:	48 89 f2             	mov    %rsi,%rdx
    b7bb:	4c 89 df             	mov    %r11,%rdi
    b7be:	4c 89 f6             	mov    %r14,%rsi
    b7c1:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    b7c6:	e8 55 b6 ff ff       	call   6e20 <memmove@plt>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b7cb:	49 8b b7 18 15 00 00 	mov    0x1518(%r15),%rsi
    b7d2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
__relocate_a_1<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/stl_uninitialized.h:1131
    b7d7:	49 89 c3             	mov    %rax,%r11
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b7da:	4c 29 f6             	sub    %r14,%rsi
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:172
    b7dd:	4c 89 f7             	mov    %r14,%rdi
deallocate():
/usr/include/c++/13/bits/new_allocator.h:172
    b7e0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    b7e5:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    b7ea:	e8 81 b3 ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
    b7ef:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    b7f4:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    b7f9:	e9 34 fe ff ff       	jmp    b632 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x152>
    b7fe:	66 90                	xchg   %ax,%ax
    b800:	48 83 c1 01          	add    $0x1,%rcx
    b804:	72 52                	jb     b858 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x378>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b806:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    b80d:	ff ff 07 
    b810:	48 39 c1             	cmp    %rax,%rcx
    b813:	48 0f 47 c8          	cmova  %rax,%rcx
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/new_allocator.h:151
    b817:	48 c1 e1 04          	shl    $0x4,%rcx
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b81b:	48 89 cd             	mov    %rcx,%rbp
    b81e:	48 89 ef             	mov    %rbp,%rdi
    b821:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b826:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    b82b:	66 0f 7e 44 24 10    	movd   %xmm0,0x10(%rsp)
    b831:	e8 2a b3 ff ff       	call   6b60 <operator new(unsigned long)@plt>
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:523
    b836:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b83b:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
    b840:	66 0f 6e 44 24 10    	movd   0x10(%rsp),%xmm0
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    b846:	49 89 c3             	mov    %rax,%r11
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:523
    b849:	48 8d 0c 28          	lea    (%rax,%rbp,1),%rcx
_M_allocate():
/usr/include/c++/13/bits/vector.tcc:523
    b84d:	e9 ba fd ff ff       	jmp    b60c <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x12c>
    b852:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
_M_check_len():
/usr/include/c++/13/bits/vector.tcc:523
    b858:	48 bd f0 ff ff ff ff 	movabs $0x7ffffffffffffff0,%rbp
    b85f:	ff ff 7f 
    b862:	eb ba                	jmp    b81e <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x33e>
    b864:	0f 1f 40 00          	nopl   0x0(%rax)
    b868:	41 89 db             	mov    %ebx,%r11d
    b86b:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484 (discriminator 2)
    b86f:	31 c0                	xor    %eax,%eax
    b871:	41 d1 eb             	shr    $1,%r11d
    b874:	49 c1 e3 04          	shl    $0x4,%r11
    b878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b87f:	00 
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b880:	f3 0f 6f 04 06       	movdqu (%rsi,%rax,1),%xmm0
    b885:	f3 0f 6f 1c 07       	movdqu (%rdi,%rax,1),%xmm3
    b88a:	66 0f d4 c3          	paddq  %xmm3,%xmm0
    b88e:	0f 11 04 06          	movups %xmm0,(%rsi,%rax,1)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:484 (discriminator 2)
    b892:	48 83 c0 10          	add    $0x10,%rax
    b896:	49 39 c3             	cmp    %rax,%r11
    b899:	75 e5                	jne    b880 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3a0>
    b89b:	89 d8                	mov    %ebx,%eax
    b89d:	83 e0 fe             	and    $0xfffffffe,%eax
    b8a0:	44 01 d0             	add    %r10d,%eax
    b8a3:	83 e3 01             	and    $0x1,%ebx
    b8a6:	0f 84 4d fe ff ff    	je     b6f9 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x219>
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 3)
    b8ac:	49 83 c0 01          	add    $0x1,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b8b0:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b8b4:	49 83 c1 10          	add    $0x10,%r9
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b8b8:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b8bc:	49 39 e8             	cmp    %rbp,%r8
    b8bf:	0f 82 c3 fd ff ff    	jb     b688 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x1a8>
    b8c5:	e9 3c fe ff ff       	jmp    b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b8ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
_M_realloc_insert<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::Chunk>():
/usr/include/c++/13/bits/vector.tcc:520
    b8d0:	49 8b b7 18 15 00 00 	mov    0x1518(%r15),%rsi
    b8d7:	4c 29 f6             	sub    %r14,%rsi
    b8da:	e9 fe fe ff ff       	jmp    b7dd <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2fd>
    b8df:	90                   	nop
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:448 (discriminator 2)
    b8e0:	49 8b 4d 00          	mov    0x0(%r13),%rcx
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
    b8e4:	48 8b 91 70 02 00 00 	mov    0x270(%rcx),%rdx
    b8eb:	48 2b 91 68 02 00 00 	sub    0x268(%rcx),%rdx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:450
    b8f2:	48 89 d6             	mov    %rdx,%rsi
    b8f5:	48 c1 fe 02          	sar    $0x2,%rsi
    b8f9:	0f 84 07 fe ff ff    	je     b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
    b8ff:	48 8b 41 68          	mov    0x68(%rcx),%rax
    b903:	48 8b 49 70          	mov    0x70(%rcx),%rcx
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    b907:	48 83 fa 0c          	cmp    $0xc,%rdx
    b90b:	77 39                	ja     b946 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x466>
    b90d:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    b911:	48 83 fa 01          	cmp    $0x1,%rdx
    b915:	0f 86 4f 01 00 00    	jbe    ba6a <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x58a>
    b91b:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    b91f:	31 d2                	xor    %edx,%edx
    b921:	48 39 f8             	cmp    %rdi,%rax
    b924:	0f 85 ad 00 00 00    	jne    b9d7 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4f7>
    b92a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b930:	48 8b 3c d1          	mov    (%rcx,%rdx,8),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b934:	48 01 3c d0          	add    %rdi,(%rax,%rdx,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:455 (discriminator 3)
    b938:	48 83 c2 01          	add    $0x1,%rdx
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:455 (discriminator 2)
    b93c:	48 39 d6             	cmp    %rdx,%rsi
    b93f:	75 ef                	jne    b930 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x450>
    b941:	e9 c0 fd ff ff       	jmp    b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b946:	48 8d 79 08          	lea    0x8(%rcx),%rdi
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    b94a:	31 d2                	xor    %edx,%edx
    b94c:	48 39 f8             	cmp    %rdi,%rax
    b94f:	0f 85 c5 00 00 00    	jne    ba1a <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x53a>
    b955:	0f 1f 00             	nopl   (%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:460 (discriminator 1)
    b958:	48 83 c2 01          	add    $0x1,%rdx
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b95c:	48 8b 7c d1 f8       	mov    -0x8(%rcx,%rdx,8),%rdi
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b961:	48 01 7c d0 f8       	add    %rdi,-0x8(%rax,%rdx,8)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b966:	48 39 d6             	cmp    %rdx,%rsi
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    b969:	75 ed                	jne    b958 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x478>
    b96b:	e9 96 fd ff ff       	jmp    b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
    b970:	48 85 f6             	test   %rsi,%rsi
    b973:	49 0f 44 fa          	cmove  %r10,%rdi
    b977:	48 89 fe             	mov    %rdi,%rsi
    b97a:	48 d1 ee             	shr    $1,%rsi
    b97d:	48 c1 e6 04          	shl    $0x4,%rsi
    b981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b988:	f3 0f 6f 04 02       	movdqu (%rdx,%rax,1),%xmm0
    b98d:	f3 0f 6f 24 01       	movdqu (%rcx,%rax,1),%xmm4
    b992:	66 0f d4 c4          	paddq  %xmm4,%xmm0
    b996:	0f 11 04 02          	movups %xmm0,(%rdx,%rax,1)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:477 (discriminator 2)
    b99a:	48 83 c0 10          	add    $0x10,%rax
    b99e:	48 39 c6             	cmp    %rax,%rsi
    b9a1:	75 e5                	jne    b988 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x4a8>
    b9a3:	48 89 f8             	mov    %rdi,%rax
    b9a6:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    b9aa:	83 e7 01             	and    $0x1,%edi
    b9ad:	0f 84 e6 fd ff ff    	je     b799 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b9>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:474 (discriminator 1)
    b9b3:	49 83 c0 08          	add    $0x8,%r8
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9b7:	48 8b 0c c1          	mov    (%rcx,%rax,8),%rcx
    b9bb:	48 01 0c c2          	add    %rcx,(%rdx,%rax,8)
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:474 (discriminator 1)
    b9bf:	4d 39 c1             	cmp    %r8,%r9
    b9c2:	0f 85 78 fd ff ff    	jne    b740 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x260>
    b9c8:	e9 d5 fd ff ff       	jmp    b7a2 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c2>
    b9cd:	0f 1f 00             	nopl   (%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:477 (discriminator 2)
    b9d0:	31 c0                	xor    %eax,%eax
    b9d2:	e9 b1 fd ff ff       	jmp    b788 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2a8>
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    b9d7:	f3 0f 6f 31          	movdqu (%rcx),%xmm6
    b9db:	f3 0f 6f 00          	movdqu (%rax),%xmm0
    b9df:	66 0f d4 c6          	paddq  %xmm6,%xmm0
    b9e3:	0f 11 00             	movups %xmm0,(%rax)
    b9e6:	48 8b 51 10          	mov    0x10(%rcx),%rdx
    b9ea:	48 01 50 10          	add    %rdx,0x10(%rax)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    b9ee:	48 83 c4 38          	add    $0x38,%rsp
    b9f2:	5b                   	pop    %rbx
    b9f3:	5d                   	pop    %rbp
    b9f4:	41 5c                	pop    %r12
    b9f6:	41 5d                	pop    %r13
    b9f8:	41 5e                	pop    %r14
    b9fa:	41 5f                	pop    %r15
    b9fc:	c3                   	ret
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
    b9fd:	48 b9 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rcx
    ba04:	ff ff 07 
    ba07:	48 39 c8             	cmp    %rcx,%rax
    ba0a:	48 0f 47 c1          	cmova  %rcx,%rax
allocate():
/usr/include/c++/13/bits/new_allocator.h:151
    ba0e:	48 c1 e0 04          	shl    $0x4,%rax
    ba12:	48 89 c5             	mov    %rax,%rbp
    ba15:	e9 04 fe ff ff       	jmp    b81e <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x33e>
    ba1a:	48 89 f7             	mov    %rsi,%rdi
    ba1d:	48 d1 ef             	shr    $1,%rdi
    ba20:	48 c1 e7 04          	shl    $0x4,%rdi
    ba24:	0f 1f 40 00          	nopl   0x0(%rax)
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    ba28:	f3 0f 6f 04 11       	movdqu (%rcx,%rdx,1),%xmm0
    ba2d:	f3 0f 6f 2c 10       	movdqu (%rax,%rdx,1),%xmm5
    ba32:	66 0f d4 c5          	paddq  %xmm5,%xmm0
    ba36:	0f 11 04 10          	movups %xmm0,(%rax,%rdx,1)
parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<(anonymous namespace)::Value, (anonymous namespace)::Step> >, sub0ecs::store::Volatile<> >::eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>((anonymous namespace)::InlinePool&, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>&&, sub0ecs::store::RowGrain<1>)::<lambda(std::size_t, unsigned int)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:26 (discriminator 2)
    ba3a:	48 83 c2 10          	add    $0x10,%rdx
    ba3e:	48 39 d7             	cmp    %rdx,%rdi
    ba41:	75 e5                	jne    ba28 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x548>
    ba43:	48 89 f2             	mov    %rsi,%rdx
    ba46:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    ba4a:	83 e6 01             	and    $0x1,%esi
    ba4d:	0f 84 b3 fc ff ff    	je     b706 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x226>
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:74
    ba53:	48 8b 0c d1          	mov    (%rcx,%rdx,8),%rcx
    ba57:	48 01 0c d0          	add    %rcx,(%rax,%rdx,8)
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
    ba5b:	48 83 c4 38          	add    $0x38,%rsp
    ba5f:	5b                   	pop    %rbx
    ba60:	5d                   	pop    %rbp
    ba61:	41 5c                	pop    %r12
    ba63:	41 5d                	pop    %r13
    ba65:	41 5e                	pop    %r14
    ba67:	41 5f                	pop    %r15
    ba69:	c3                   	ret
eachParallel<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::InlinePool, (anonymous namespace)::Ecs<1>::tick()::<lambda(unsigned int, (anonymous namespace)::Value&, const (anonymous namespace)::Step&)>, 1>():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:453
    ba6a:	31 d2                	xor    %edx,%edx
    ba6c:	e9 bf fe ff ff       	jmp    b930 <std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x450>
_M_check_len():
/usr/include/c++/13/bits/stl_vector.h:1899
    ba71:	48 8d 3d 8c 05 05 00 	lea    0x5058c(%rip),%rdi        # 5c004 <_IO_stdin_used+0x4>
    ba78:	e8 43 af ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>
std::_Function_handler<void (), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/stl_vector.h:1899
    ba7d:	0f 1f 00             	nopl   (%rax)


0000000000012880 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)>:
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:288
   12880:	f3 0f 1e fa          	endbr64
   12884:	41 57                	push   %r15
   12886:	41 56                	push   %r14
   12888:	41 55                	push   %r13
   1288a:	41 54                	push   %r12
   1288c:	55                   	push   %rbp
   1288d:	48 89 f5             	mov    %rsi,%rbp
   12890:	53                   	push   %rbx
   12891:	48 83 ec 48          	sub    $0x48,%rsp
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   12895:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1289c:	00 00 
get():
/usr/include/c++/13/bits/shared_ptr_base.h:1666
   1289e:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   128a3:	48 8b 07             	mov    (%rdi),%rax
   128a6:	48 8b 00             	mov    (%rax),%rax
__gnu_cxx::__normal_iterator<sub0ecs::store::Partition**, std::vector<sub0ecs::store::Partition*, std::allocator<sub0ecs::store::Partition*> > >::__normal_iterator(sub0ecs::store::Partition** const&):
/usr/include/c++/13/bits/stl_iterator.h:1077
   128a9:	48 8b 88 38 15 00 00 	mov    0x1538(%rax),%rcx
   128b0:	4c 8b 90 40 15 00 00 	mov    0x1540(%rax),%r10
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   128b7:	4c 39 d1             	cmp    %r10,%rcx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   128ba:	0f 84 03 04 00 00    	je     12cc3 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x443>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   128c0:	31 d2                	xor    %edx,%edx
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:78
   128c2:	eb 14                	jmp    128d8 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   128c4:	48 83 c1 08          	add    $0x8,%rcx
   128c8:	49 39 ca             	cmp    %rcx,%r10
   128cb:	0f 84 97 00 00 00    	je     12968 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xe8>
   128d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 3)
   128d8:	48 8b 01             	mov    (%rcx),%rax
std::vector<sub0ecs::Entity, std::allocator<sub0ecs::Entity> >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   128db:	4c 8b 88 70 02 00 00 	mov    0x270(%rax),%r9
   128e2:	4c 8b 80 68 02 00 00 	mov    0x268(%rax),%r8
   128e9:	4c 89 ce             	mov    %r9,%rsi
   128ec:	4c 29 c6             	sub    %r8,%rsi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:197
   128ef:	49 89 f3             	mov    %rsi,%r11
   128f2:	49 c1 fb 02          	sar    $0x2,%r11
   128f6:	74 cc                	je     128c4 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:122 (discriminator 1)
   128f8:	48 8b 78 68          	mov    0x68(%rax),%rdi
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   128fc:	4d 39 c1             	cmp    %r8,%r9
   128ff:	74 c3                	je     128c4 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
   12901:	48 83 fe 04          	cmp    $0x4,%rsi
   12905:	0f 84 38 01 00 00    	je     12a43 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1c3>
   1290b:	4c 89 de             	mov    %r11,%rsi
   1290e:	48 89 f8             	mov    %rdi,%rax
   12911:	66 0f ef c0          	pxor   %xmm0,%xmm0
   12915:	48 d1 ee             	shr    $1,%rsi
   12918:	48 c1 e6 04          	shl    $0x4,%rsi
   1291c:	48 01 fe             	add    %rdi,%rsi
   1291f:	90                   	nop
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   12920:	f3 0f 6f 10          	movdqu (%rax),%xmm2
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   12924:	48 83 c0 10          	add    $0x10,%rax
   12928:	66 0f d4 c2          	paddq  %xmm2,%xmm0
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199 (discriminator 2)
   1292c:	48 39 c6             	cmp    %rax,%rsi
   1292f:	75 ef                	jne    12920 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xa0>
   12931:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   12935:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
   1293a:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   1293e:	66 48 0f 7e c0       	movq   %xmm0,%rax
   12943:	48 01 c2             	add    %rax,%rdx
   12946:	4c 89 d8             	mov    %r11,%rax
   12949:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   1294d:	41 83 e3 01          	and    $0x1,%r11d
   12951:	0f 84 6d ff ff ff    	je     128c4 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x44>
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12957:	48 83 c1 08          	add    $0x8,%rcx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:79
   1295b:	48 03 14 c7          	add    (%rdi,%rax,8),%rdx
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   1295f:	49 39 ca             	cmp    %rcx,%r10
   12962:	0f 85 70 ff ff ff    	jne    128d8 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x58>
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:80
   12968:	48 85 d2             	test   %rdx,%rdx
   1296b:	0f 88 af 00 00 00    	js     12a20 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1a0>
   12971:	66 0f ef e4          	pxor   %xmm4,%xmm4
   12975:	f2 48 0f 2a e2       	cvtsi2sd %rdx,%xmm4
   1297a:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   1297f:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   12984:	c6 44 24 28 00       	movb   $0x0,0x28(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12989:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   12990:	73 75 6d 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   12993:	48 8b 9d 50 01 00 00 	mov    0x150(%rbp),%rbx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char> const&):
/usr/include/c++/13/bits/basic_string.h:189 (discriminator 1)
   1299a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   1299f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   129a4:	48 c7 44 24 18 08 00 	movq   $0x8,0x18(%rsp)
   129ab:	00 00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:114
   129ad:	48 3b 9d 58 01 00 00 	cmp    0x158(%rbp),%rbx
   129b4:	0f 84 90 00 00 00    	je     12a4a <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x1ca>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   129ba:	48 8d 53 10          	lea    0x10(%rbx),%rdx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   129be:	48 89 13             	mov    %rdx,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   129c1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   129c6:	4c 39 e0             	cmp    %r12,%rax
   129c9:	0f 84 e1 02 00 00    	je     12cb0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x430>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   129cf:	48 89 03             	mov    %rax,(%rbx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   129d2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   129d7:	48 89 43 10          	mov    %rax,0x10(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   129db:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   129e0:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
   129e7:	00 
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   129e8:	f2 0f 11 5b 20       	movsd  %xmm3,0x20(%rbx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>& std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::emplace_back<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:119
   129ed:	48 83 85 50 01 00 00 	addq   $0x28,0x150(%rbp)
   129f4:	28 
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   129f5:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   129fa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   12a01:	00 00 
   12a03:	0f 85 8f 03 00 00    	jne    12d98 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   12a09:	48 83 c4 48          	add    $0x48,%rsp
   12a0d:	5b                   	pop    %rbx
   12a0e:	5d                   	pop    %rbp
   12a0f:	41 5c                	pop    %r12
   12a11:	41 5d                	pop    %r13
   12a13:	41 5e                	pop    %r14
   12a15:	41 5f                	pop    %r15
   12a17:	c3                   	ret
   12a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   12a1f:	00 
checksum():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:80
   12a20:	48 89 d0             	mov    %rdx,%rax
   12a23:	83 e2 01             	and    $0x1,%edx
   12a26:	66 0f ef c0          	pxor   %xmm0,%xmm0
   12a2a:	48 d1 e8             	shr    $1,%rax
   12a2d:	48 09 d0             	or     %rdx,%rax
   12a30:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   12a35:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   12a39:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
   12a3e:	e9 3c ff ff ff       	jmp    1297f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:199
   12a43:	31 c0                	xor    %eax,%eax
   12a45:	e9 0d ff ff ff       	jmp    12957 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xd7>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:445
   12a4a:	4c 8b ad 48 01 00 00 	mov    0x148(%rbp),%r13
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::size() const:
/usr/include/c++/13/bits/stl_vector.h:993
   12a51:	49 89 de             	mov    %rbx,%r14
   12a54:	48 ba cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rdx
   12a5b:	cc cc cc 
   12a5e:	4d 29 ee             	sub    %r13,%r14
   12a61:	4c 89 f0             	mov    %r14,%rax
   12a64:	48 c1 f8 03          	sar    $0x3,%rax
   12a68:	48 0f af c2          	imul   %rdx,%rax
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1898 (discriminator 2)
   12a6c:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   12a73:	33 33 03 
   12a76:	48 39 d0             	cmp    %rdx,%rax
   12a79:	0f 84 1e 03 00 00    	je     12d9d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x51d>
unsigned long const& std::max<unsigned long>(unsigned long const&, unsigned long const&):
/usr/include/c++/13/bits/stl_algobase.h:262
   12a7f:	4c 39 eb             	cmp    %r13,%rbx
   12a82:	74 6c                	je     12af0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x270>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1901 (discriminator 3)
   12a84:	48 8d 14 00          	lea    (%rax,%rax,1),%rdx
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12a88:	48 39 c2             	cmp    %rax,%rdx
   12a8b:	0f 82 3f 02 00 00    	jb     12cd0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381
   12a91:	48 85 d2             	test   %rdx,%rdx
   12a94:	0f 85 e4 02 00 00    	jne    12d7e <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4fe>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12a9a:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12a9e:	41 bf 28 00 00 00    	mov    $0x28,%r15d
   12aa4:	ba 08 00 00 00       	mov    $0x8,%edx
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_allocate(unsigned long):
/usr/include/c++/13/bits/stl_vector.h:381 (discriminator 2)
   12aa9:	45 31 c0             	xor    %r8d,%r8d
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12aac:	49 89 0e             	mov    %rcx,(%r14)
   12aaf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   12ab6:	00 00 
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   12ab8:	48 8d 42 01          	lea    0x1(%rdx),%rax
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12abc:	83 f8 08             	cmp    $0x8,%eax
   12abf:	0f 83 1a 02 00 00    	jae    12cdf <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x45f>
   12ac5:	a8 04                	test   $0x4,%al
   12ac7:	0f 85 8f 02 00 00    	jne    12d5c <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4dc>
   12acd:	85 c0                	test   %eax,%eax
   12acf:	74 7c                	je     12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12ad1:	0f b6 74 24 20       	movzbl 0x20(%rsp),%esi
   12ad6:	40 88 31             	mov    %sil,(%rcx)
   12ad9:	a8 02                	test   $0x2,%al
   12adb:	74 70                	je     12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12add:	89 c0                	mov    %eax,%eax
   12adf:	41 0f b7 74 04 fe    	movzwl -0x2(%r12,%rax,1),%esi
   12ae5:	66 89 74 01 fe       	mov    %si,-0x2(%rcx,%rax,1)
   12aea:	eb 61                	jmp    12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12aec:	0f 1f 40 00          	nopl   0x0(%rax)
   12af0:	48 83 c0 01          	add    $0x1,%rax
   12af4:	0f 82 d6 01 00 00    	jb     12cd0 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x450>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12afa:	48 ba 33 33 33 33 33 	movabs $0x333333333333333,%rdx
   12b01:	33 33 03 
   12b04:	48 39 d0             	cmp    %rdx,%rax
   12b07:	48 0f 47 c2          	cmova  %rdx,%rax
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   12b0b:	4c 8d 3c 80          	lea    (%rax,%rax,4),%r15
   12b0f:	49 c1 e7 03          	shl    $0x3,%r15
   12b13:	4c 89 ff             	mov    %r15,%rdi
   12b16:	e8 45 40 ff ff       	call   6b60 <operator new(unsigned long)@plt>
   12b1b:	49 89 c0             	mov    %rax,%r8
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12b1e:	4a 8d 04 38          	lea    (%rax,%r15,1),%rax
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:266
   12b22:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12b27:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12b2c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   12b31:	4d 8d 78 28          	lea    0x28(%r8),%r15
/usr/include/c++/13/bits/vector.tcc:468
   12b35:	4d 01 c6             	add    %r8,%r14
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12b38:	4c 39 e0             	cmp    %r12,%rax
   12b3b:	0f 84 31 02 00 00    	je     12d72 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4f2>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12b41:	49 89 06             	mov    %rax,(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   12b44:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   12b49:	49 89 46 10          	mov    %rax,0x10(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12b4d:	f2 0f 10 2c 24       	movsd  (%rsp),%xmm5
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12b52:	49 89 56 08          	mov    %rdx,0x8(%r14)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12b56:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12b5b:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   12b62:	00 00 
std::char_traits<char>::assign(char&, char const&):
/usr/include/c++/13/bits/char_traits.h:358
   12b64:	c6 44 24 20 00       	movb   $0x0,0x20(%rsp)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/stl_pair.h:317 (discriminator 1)
   12b69:	f2 41 0f 11 6e 20    	movsd  %xmm5,0x20(%r14)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   12b6f:	4c 39 eb             	cmp    %r13,%rbx
   12b72:	0f 84 8f 00 00 00    	je     12c07 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x387>
   12b78:	4c 89 e8             	mov    %r13,%rax
/usr/include/c++/13/bits/stl_uninitialized.h:1103
   12b7b:	4c 89 c2             	mov    %r8,%rdx
   12b7e:	eb 2a                	jmp    12baa <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x32a>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data(char*):
/usr/include/c++/13/bits/basic_string.h:213
   12b80:	48 89 0a             	mov    %rcx,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_capacity(unsigned long):
/usr/include/c++/13/bits/basic_string.h:250
   12b83:	48 8b 48 10          	mov    0x10(%rax),%rcx
   12b87:	48 89 4a 10          	mov    %rcx,0x10(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12b8b:	48 8b 48 08          	mov    0x8(%rax),%rcx
   12b8f:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   12b93:	f2 0f 10 40 20       	movsd  0x20(%rax),%xmm0
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 2)
   12b98:	48 83 c0 28          	add    $0x28,%rax
   12b9c:	48 83 c2 28          	add    $0x28,%rdx
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>::pair(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>&&):
/usr/include/c++/13/bits/stl_pair.h:198 (discriminator 1)
   12ba0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>* std::__relocate_a_1<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >&):
/usr/include/c++/13/bits/stl_uninitialized.h:1104 (discriminator 1)
   12ba5:	48 39 c3             	cmp    %rax,%rbx
   12ba8:	74 4d                	je     12bf7 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x377>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12baa:	48 8d 72 10          	lea    0x10(%rdx),%rsi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:241
   12bae:	48 8d 78 10          	lea    0x10(%rax),%rdi
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12bb2:	48 89 32             	mov    %rsi,(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12bb5:	48 8b 08             	mov    (%rax),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12bb8:	48 39 f9             	cmp    %rdi,%rcx
   12bbb:	75 c3                	jne    12b80 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x300>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&):
/usr/include/c++/13/bits/basic_string.h:683
   12bbd:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12bc1:	49 8d 79 01          	lea    0x1(%r9),%rdi
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12bc5:	83 ff 08             	cmp    $0x8,%edi
   12bc8:	0f 83 97 00 00 00    	jae    12c65 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x3e5>
   12bce:	40 f6 c7 04          	test   $0x4,%dil
   12bd2:	0f 85 56 01 00 00    	jne    12d2e <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4ae>
   12bd8:	85 ff                	test   %edi,%edi
   12bda:	74 15                	je     12bf1 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12bdc:	44 0f b6 09          	movzbl (%rcx),%r9d
   12be0:	44 88 0e             	mov    %r9b,(%rsi)
   12be3:	40 f6 c7 02          	test   $0x2,%dil
   12be7:	0f 85 5a 01 00 00    	jne    12d47 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x4c7>
   12bed:	4c 8b 48 08          	mov    0x8(%rax),%r9
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:218
   12bf1:	4c 89 4a 08          	mov    %r9,0x8(%rdx)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_set_length(unsigned long):
/usr/include/c++/13/bits/basic_string.h:254
   12bf5:	eb 9c                	jmp    12b93 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x313>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:483
   12bf7:	48 8d 43 d8          	lea    -0x28(%rbx),%rax
   12bfb:	4c 29 e8             	sub    %r13,%rax
   12bfe:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   12c02:	4d 8d 7c 00 50       	lea    0x50(%r8,%rax,1),%r15
std::_Vector_base<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/stl_vector.h:389
   12c07:	4d 85 ed             	test   %r13,%r13
   12c0a:	0f 84 a9 01 00 00    	je     12db9 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x539>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   12c10:	48 8b b5 58 01 00 00 	mov    0x158(%rbp),%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12c17:	4c 89 ef             	mov    %r13,%rdi
   12c1a:	4c 89 04 24          	mov    %r8,(%rsp)
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:520
   12c1e:	4c 29 ee             	sub    %r13,%rsi
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::deallocate(std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12c21:	e8 4a 3f ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   12c26:	4c 8b 04 24          	mov    (%rsp),%r8
/usr/include/c++/13/bits/vector.tcc:523
   12c2a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:522
   12c2f:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_data() const:
/usr/include/c++/13/bits/basic_string.h:223
   12c36:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:521
   12c3b:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   12c42:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_is_local() const:
/usr/include/c++/13/bits/basic_string.h:264 (discriminator 2)
   12c49:	4c 39 e7             	cmp    %r12,%rdi
   12c4c:	0f 84 a3 fd ff ff    	je     129f5 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_destroy(unsigned long):
/usr/include/c++/13/bits/basic_string.h:289
   12c52:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   12c57:	48 8d 70 01          	lea    0x1(%rax),%rsi
std::__new_allocator<char>::deallocate(char*, unsigned long):
/usr/include/c++/13/bits/new_allocator.h:172
   12c5b:	e8 10 3f ff ff       	call   6b70 <operator delete(void*, unsigned long)@plt>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:291
   12c60:	e9 90 fd ff ff       	jmp    129f5 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12c65:	4c 8b 09             	mov    (%rcx),%r9
   12c68:	4c 89 0e             	mov    %r9,(%rsi)
   12c6b:	41 89 f9             	mov    %edi,%r9d
   12c6e:	4e 8b 54 09 f8       	mov    -0x8(%rcx,%r9,1),%r10
   12c73:	4e 89 54 0e f8       	mov    %r10,-0x8(%rsi,%r9,1)
   12c78:	4c 8d 4a 18          	lea    0x18(%rdx),%r9
   12c7c:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
   12c80:	4c 29 ce             	sub    %r9,%rsi
   12c83:	01 f7                	add    %esi,%edi
   12c85:	48 29 f1             	sub    %rsi,%rcx
   12c88:	83 e7 f8             	and    $0xfffffff8,%edi
   12c8b:	83 ff 08             	cmp    $0x8,%edi
   12c8e:	0f 82 59 ff ff ff    	jb     12bed <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   12c94:	83 e7 f8             	and    $0xfffffff8,%edi
   12c97:	31 f6                	xor    %esi,%esi
   12c99:	41 89 f2             	mov    %esi,%r10d
   12c9c:	83 c6 08             	add    $0x8,%esi
   12c9f:	4e 8b 1c 11          	mov    (%rcx,%r10,1),%r11
   12ca3:	4f 89 1c 11          	mov    %r11,(%r9,%r10,1)
   12ca7:	39 fe                	cmp    %edi,%esi
   12ca9:	72 ee                	jb     12c99 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x419>
   12cab:	e9 3d ff ff ff       	jmp    12bed <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x36d>
   12cb0:	48 8b 08             	mov    (%rax),%rcx
   12cb3:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   12cb7:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   12cbb:	88 42 08             	mov    %al,0x8(%rdx)
   12cbe:	e9 18 fd ff ff       	jmp    129db <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x15b>
each<(anonymous namespace)::Value, (anonymous namespace)::Step, (anonymous namespace)::Ecs<1>::checksum()::<lambda(const (anonymous namespace)::Value&, const (anonymous namespace)::Step&)> >():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12cc3:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   12cca:	00 
   12ccb:	e9 af fc ff ff       	jmp    1297f <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0xff>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/workspace/scratch/df8f5a8b05e6/Sub0ECS/include/sub0ecs/store/world.hpp:194 (discriminator 1)
   12cd0:	49 bf f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r15
   12cd7:	ff ff 7f 
   12cda:	e9 34 fe ff ff       	jmp    12b13 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::char_traits<char>::copy(char*, char const*, unsigned long):
/usr/include/c++/13/bits/char_traits.h:435
   12cdf:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   12ce4:	48 89 31             	mov    %rsi,(%rcx)
   12ce7:	89 c6                	mov    %eax,%esi
   12ce9:	49 8b 7c 34 f8       	mov    -0x8(%r12,%rsi,1),%rdi
   12cee:	48 89 7c 31 f8       	mov    %rdi,-0x8(%rcx,%rsi,1)
   12cf3:	48 8d 71 08          	lea    0x8(%rcx),%rsi
   12cf7:	4c 89 e7             	mov    %r12,%rdi
   12cfa:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   12cfe:	48 29 f1             	sub    %rsi,%rcx
   12d01:	01 c8                	add    %ecx,%eax
   12d03:	48 29 cf             	sub    %rcx,%rdi
   12d06:	83 e0 f8             	and    $0xfffffff8,%eax
   12d09:	83 f8 08             	cmp    $0x8,%eax
   12d0c:	0f 82 3b fe ff ff    	jb     12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12d12:	83 e0 f8             	and    $0xfffffff8,%eax
   12d15:	31 c9                	xor    %ecx,%ecx
   12d17:	41 89 c9             	mov    %ecx,%r9d
   12d1a:	83 c1 08             	add    $0x8,%ecx
   12d1d:	4e 8b 14 0f          	mov    (%rdi,%r9,1),%r10
   12d21:	4e 89 14 0e          	mov    %r10,(%rsi,%r9,1)
   12d25:	39 c1                	cmp    %eax,%ecx
   12d27:	72 ee                	jb     12d17 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x497>
   12d29:	e9 1f fe ff ff       	jmp    12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
   12d2e:	44 8b 09             	mov    (%rcx),%r9d
   12d31:	89 ff                	mov    %edi,%edi
   12d33:	44 89 0e             	mov    %r9d,(%rsi)
   12d36:	8b 4c 39 fc          	mov    -0x4(%rcx,%rdi,1),%ecx
   12d3a:	89 4c 3e fc          	mov    %ecx,-0x4(%rsi,%rdi,1)
   12d3e:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12d42:	e9 aa fe ff ff       	jmp    12bf1 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12d47:	89 ff                	mov    %edi,%edi
   12d49:	0f b7 4c 39 fe       	movzwl -0x2(%rcx,%rdi,1),%ecx
   12d4e:	66 89 4c 3e fe       	mov    %cx,-0x2(%rsi,%rdi,1)
   12d53:	4c 8b 48 08          	mov    0x8(%rax),%r9
   12d57:	e9 95 fe ff ff       	jmp    12bf1 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x371>
   12d5c:	8b 74 24 20          	mov    0x20(%rsp),%esi
   12d60:	89 c0                	mov    %eax,%eax
   12d62:	89 31                	mov    %esi,(%rcx)
   12d64:	41 8b 74 04 fc       	mov    -0x4(%r12,%rax,1),%esi
   12d69:	89 74 01 fc          	mov    %esi,-0x4(%rcx,%rax,1)
   12d6d:	e9 db fd ff ff       	jmp    12b4d <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x2cd>
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data():
/usr/include/c++/13/bits/basic_string.h:230
   12d72:	49 8d 4e 10          	lea    0x10(%r14),%rcx
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_Alloc_hider::_Alloc_hider(char*, std::allocator<char>&&):
/usr/include/c++/13/bits/basic_string.h:193 (discriminator 1)
   12d76:	49 89 0e             	mov    %rcx,(%r14)
   12d79:	e9 3a fd ff ff       	jmp    12ab8 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x238>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1902 (discriminator 1)
   12d7e:	48 b8 33 33 33 33 33 	movabs $0x333333333333333,%rax
   12d85:	33 33 03 
   12d88:	48 39 c2             	cmp    %rax,%rdx
   12d8b:	48 0f 47 d0          	cmova  %rax,%rdx
std::__new_allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> >::allocate(unsigned long, void const*):
/usr/include/c++/13/bits/new_allocator.h:151
   12d8f:	4c 6b fa 28          	imul   $0x28,%rdx,%r15
   12d93:	e9 7b fd ff ff       	jmp    12b13 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x293>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/std_function.h:292
   12d98:	e8 33 3e ff ff       	call   6bd0 <__stack_chk_fail@plt>
std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_check_len(unsigned long, char const*) const:
/usr/include/c++/13/bits/stl_vector.h:1899
   12d9d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   12da2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   12da9:	00 00 
   12dab:	75 eb                	jne    12d98 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x518>
   12dad:	48 8d 3d 50 92 04 00 	lea    0x49250(%rip),%rdi        # 5c004 <_IO_stdin_used+0x4>
   12db4:	e8 07 3c ff ff       	call   69c0 <std::__throw_length_error(char const*)@plt>
void std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > >::_M_realloc_insert<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double&>(__gnu_cxx::__normal_iterator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>*, std::vector<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double>, std::allocator<std::pair<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double> > > >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >&&, double&):
/usr/include/c++/13/bits/vector.tcc:523
   12db9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
/usr/include/c++/13/bits/vector.tcc:521
   12dbe:	4c 89 85 48 01 00 00 	mov    %r8,0x148(%rbp)
/usr/include/c++/13/bits/vector.tcc:522
   12dc5:	4c 89 bd 50 01 00 00 	mov    %r15,0x150(%rbp)
/usr/include/c++/13/bits/vector.tcc:523
   12dcc:	48 89 85 58 01 00 00 	mov    %rax,0x158(%rbp)
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_local_data() const:
/usr/include/c++/13/bits/basic_string.h:238
   12dd3:	e9 1d fc ff ff       	jmp    129f5 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&)+0x175>
   12dd8:	f3 0f 1e fa          	endbr64
std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::~basic_string():
/usr/include/c++/13/bits/basic_string.h:804
   12ddc:	48 89 c3             	mov    %rax,%rbx
   12ddf:	e9 85 46 ff ff       	jmp    7469 <std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&) [clone .cold]>
std::_Function_handler<void (bench::harness::Record&), (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)::{lambda(bench::harness::Record&)#1}>::_M_invoke(std::_Any_data const&, bench::harness::Record&):
/usr/include/c++/13/bits/basic_string.h:804
   12de4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12deb:	00 00 00 00 
   12def:	90                   	nop


0000000000019be0 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   19be0:	f3 0f 1e fa          	endbr64
   19be4:	53                   	push   %rbx
   19be5:	48 89 fb             	mov    %rdi,%rbx
   19be8:	48 83 ec 10          	sub    $0x10,%rsp
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19bec:	0f b6 56 08          	movzbl 0x8(%rsi),%edx
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19bf0:	48 8b 36             	mov    (%rsi),%rsi
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:288
   19bf3:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   19bfa:	00 00 
   19bfc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   19c01:	31 c0                	xor    %eax,%eax
operator()():
/workspace/scratch/df8f5a8b05e6/Sub0ECS/bench/rows/bench.cpp:105
   19c03:	e8 58 ee ff ff       	call   18a60 <bench::harness::Prepared (anonymous namespace)::prepare<(anonymous namespace)::Ecs<1ul> >(unsigned long, bool)>
std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&):
/usr/include/c++/13/bits/std_function.h:292
   19c08:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   19c0d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   19c14:	00 00 
   19c16:	75 09                	jne    19c21 <std::_Function_handler<bench::harness::Prepared (), (anonymous namespace)::add<(anonymous namespace)::Ecs<1ul> >(bench::harness::Registry&, char const*, unsigned long, bool)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x41>
   19c18:	48 83 c4 10          	add    $0x10,%rsp
   19c1c:	48 89 d8             	mov    %rbx,%rax
   19c1f:	5b                   	pop    %rbx
   19c20:	c3                   	ret
   19c21:	e8 aa cf fe ff       	call   6bd0 <__stack_chk_fail@plt>
   19c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   19c2d:	00 00 00 

