0000000000028990 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
   28990:	f3 0f 1e fa          	endbr64
   28994:	48 8b 0f             	mov    (%rdi),%rcx
   28997:	8b 57 08             	mov    0x8(%rdi),%edx
   2899a:	4c 8b 51 10          	mov    0x10(%rcx),%r10
   2899e:	48 8b 71 18          	mov    0x18(%rcx),%rsi
   289a2:	48 89 d0             	mov    %rdx,%rax
   289a5:	49 0f af c2          	imul   %r10,%rax
   289a9:	48 39 d6             	cmp    %rdx,%rsi
   289ac:	0f 82 52 05 00 00    	jb     28f04 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x574>
   289b2:	48 01 d0             	add    %rdx,%rax
   289b5:	48 39 f2             	cmp    %rsi,%rdx
   289b8:	49 83 d2 00          	adc    $0x0,%r10
   289bc:	4d 85 d2             	test   %r10,%r10
   289bf:	0f 84 4b 05 00 00    	je     28f10 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x580>
   289c5:	f2 44 0f 10 0d a2 89 	movsd  0x689a2(%rip),%xmm9        # 91370 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x18>
   289cc:	06 00 
   289ce:	41 57                	push   %r15
   289d0:	4d 89 d3             	mov    %r10,%r11
   289d3:	41 56                	push   %r14
   289d5:	49 89 c6             	mov    %rax,%r14
   289d8:	41 55                	push   %r13
   289da:	49 c1 e6 09          	shl    $0x9,%r14
   289de:	45 31 ed             	xor    %r13d,%r13d
   289e1:	41 54                	push   %r12
   289e3:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
   289e7:	55                   	push   %rbp
   289e8:	49 c1 e4 09          	shl    $0x9,%r12
   289ec:	53                   	push   %rbx
   289ed:	4c 8b 39             	mov    (%rcx),%r15
   289f0:	49 8b 4f 10          	mov    0x10(%r15),%rcx
   289f4:	49 8b 57 08          	mov    0x8(%r15),%rdx
   289f8:	4d 89 f9             	mov    %r15,%r9
   289fb:	48 8b 71 18          	mov    0x18(%rcx),%rsi
   289ff:	48 8b 1a             	mov    (%rdx),%rbx
   28a02:	4c 8b 01             	mov    (%rcx),%r8
   28a05:	49 8b 17             	mov    (%r15),%rdx
   28a08:	48 89 74 24 a8       	mov    %rsi,-0x58(%rsp)
   28a0d:	48 8b 71 10          	mov    0x10(%rcx),%rsi
   28a11:	48 89 c1             	mov    %rax,%rcx
   28a14:	48 c1 e1 06          	shl    $0x6,%rcx
   28a18:	48 89 5c 24 a0       	mov    %rbx,-0x60(%rsp)
   28a1d:	48 8b 12             	mov    (%rdx),%rdx
   28a20:	48 89 74 24 b0       	mov    %rsi,-0x50(%rsp)
   28a25:	48 29 cb             	sub    %rcx,%rbx
   28a28:	48 89 dd             	mov    %rbx,%rbp
   28a2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28a30:	48 39 ea             	cmp    %rbp,%rdx
   28a33:	49 89 ef             	mov    %rbp,%r15
   28a36:	4c 0f 46 fa          	cmovbe %rdx,%r15
   28a3a:	4d 85 ff             	test   %r15,%r15
   28a3d:	0f 84 76 04 00 00    	je     28eb9 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x529>
   28a43:	49 8b 41 18          	mov    0x18(%r9),%rax
   28a47:	4c 89 74 24 88       	mov    %r14,-0x78(%rsp)
   28a4c:	4f 8d 14 06          	lea    (%r14,%r8,1),%r10
   28a50:	4c 89 6c 24 90       	mov    %r13,-0x70(%rsp)
   28a55:	48 8b 00             	mov    (%rax),%rax
   28a58:	4c 89 64 24 98       	mov    %r12,-0x68(%rsp)
   28a5d:	48 8b b8 50 15 00 00 	mov    0x1550(%rax),%rdi
   28a64:	48 8b 98 58 15 00 00 	mov    0x1558(%rax),%rbx
   28a6b:	48 8b 44 24 a8       	mov    -0x58(%rsp),%rax
   28a70:	48 29 fb             	sub    %rdi,%rbx
   28a73:	4a 8d 34 20          	lea    (%rax,%r12,1),%rsi
   28a77:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
   28a7c:	48 c1 fb 05          	sar    $0x5,%rbx
   28a80:	4a 8d 0c 20          	lea    (%rax,%r12,1),%rcx
   28a84:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
   28a89:	48 29 e8             	sub    %rbp,%rax
   28a8c:	4c 01 f8             	add    %r15,%rax
   28a8f:	4d 8d 3c c0          	lea    (%r8,%rax,8),%r15
   28a93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28a98:	4d 8b 2a             	mov    (%r10),%r13
   28a9b:	66 0f 10 1e          	movupd (%rsi),%xmm3
   28a9f:	f2 0f 10 66 10       	movsd  0x10(%rsi),%xmm4
   28aa4:	66 0f 10 31          	movupd (%rcx),%xmm6
   28aa8:	f2 0f 10 69 10       	movsd  0x10(%rcx),%xmm5
   28aad:	4d 85 ed             	test   %r13,%r13
   28ab0:	0f 84 32 04 00 00    	je     28ee8 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x558>
   28ab6:	49 83 fd 01          	cmp    $0x1,%r13
   28aba:	0f 84 35 04 00 00    	je     28ef5 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x565>
   28ac0:	4d 89 ec             	mov    %r13,%r12
   28ac3:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   28ac8:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   28acd:	48 89 f8             	mov    %rdi,%rax
   28ad0:	66 44 0f 28 d4       	movapd %xmm4,%xmm10
   28ad5:	49 d1 ec             	shr    $1,%r12
   28ad8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   28adc:	66 0f ef c9          	pxor   %xmm1,%xmm1
   28ae0:	49 c1 e4 06          	shl    $0x6,%r12
   28ae4:	66 44 0f 14 e3       	unpcklpd %xmm3,%xmm12
   28ae9:	66 44 0f 15 db       	unpckhpd %xmm3,%xmm11
   28aee:	66 45 0f 14 d2       	unpcklpd %xmm10,%xmm10
   28af3:	49 01 fc             	add    %rdi,%r12
   28af6:	66 44 0f 10 28       	movupd (%rax),%xmm13
   28afb:	66 44 0f 10 70 20    	movupd 0x20(%rax),%xmm14
   28b01:	48 83 c0 40          	add    $0x40,%rax
   28b05:	66 0f 10 50 d0       	movupd -0x30(%rax),%xmm2
   28b0a:	66 44 0f 10 78 f0    	movupd -0x10(%rax),%xmm15
   28b10:	66 44 0f 16 68 d0    	movhpd -0x30(%rax),%xmm13
   28b16:	66 44 0f 12 78 e8    	movlpd -0x18(%rax),%xmm15
   28b1c:	66 0f 12 50 c8       	movlpd -0x38(%rax),%xmm2
   28b21:	66 44 0f 16 70 f0    	movhpd -0x10(%rax),%xmm14
   28b27:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   28b2c:	66 45 0f 15 ee       	unpckhpd %xmm14,%xmm13
   28b31:	66 0f 28 fa          	movapd %xmm2,%xmm7
   28b35:	66 45 0f 14 c6       	unpcklpd %xmm14,%xmm8
   28b3a:	66 41 0f 14 d7       	unpcklpd %xmm15,%xmm2
   28b3f:	66 45 0f 5c c4       	subpd  %xmm12,%xmm8
   28b44:	66 41 0f 5c d3       	subpd  %xmm11,%xmm2
   28b49:	66 41 0f 15 ff       	unpckhpd %xmm15,%xmm7
   28b4e:	66 45 0f 5c ea       	subpd  %xmm10,%xmm13
   28b53:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   28b58:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   28b5d:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
   28b62:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   28b67:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   28b6c:	66 45 0f 28 fd       	movapd %xmm13,%xmm15
   28b71:	66 45 0f 59 fd       	mulpd  %xmm13,%xmm15
   28b76:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   28b7b:	66 44 0f 58 35 ec 87 	addpd  0x687ec(%rip),%xmm14        # 91370 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x18>
   28b82:	06 00 
   28b84:	66 45 0f 51 fe       	sqrtpd %xmm14,%xmm15
   28b89:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   28b8e:	66 41 0f 5e fe       	divpd  %xmm14,%xmm7
   28b93:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   28b98:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   28b9c:	66 41 0f 59 fd       	mulpd  %xmm13,%xmm7
   28ba1:	66 45 0f 28 f0       	movapd %xmm8,%xmm14
   28ba6:	66 44 0f 14 f2       	unpcklpd %xmm2,%xmm14
   28bab:	66 44 0f 15 c2       	unpckhpd %xmm2,%xmm8
   28bb0:	f2 0f 58 cf          	addsd  %xmm7,%xmm1
   28bb4:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   28bb9:	66 0f 15 ff          	unpckhpd %xmm7,%xmm7
   28bbd:	66 41 0f 58 c0       	addpd  %xmm8,%xmm0
   28bc2:	f2 0f 58 cf          	addsd  %xmm7,%xmm1
   28bc6:	49 39 c4             	cmp    %rax,%r12
   28bc9:	0f 85 27 ff ff ff    	jne    28af6 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x166>
   28bcf:	41 f6 c5 01          	test   $0x1,%r13b
   28bd3:	0f 84 88 00 00 00    	je     28c61 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2d1>
   28bd9:	4c 89 e8             	mov    %r13,%rax
   28bdc:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   28be0:	48 c1 e0 05          	shl    $0x5,%rax
   28be4:	48 01 f8             	add    %rdi,%rax
   28be7:	66 44 0f 10 10       	movupd (%rax),%xmm10
   28bec:	f2 44 0f 10 40 10    	movsd  0x10(%rax),%xmm8
   28bf2:	66 44 0f 5c d3       	subpd  %xmm3,%xmm10
   28bf7:	f2 44 0f 5c c4       	subsd  %xmm4,%xmm8
   28bfc:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   28c01:	66 0f 15 ff          	unpckhpd %xmm7,%xmm7
   28c05:	66 0f 28 d7          	movapd %xmm7,%xmm2
   28c09:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   28c0e:	f2 41 0f 59 fa       	mulsd  %xmm10,%xmm7
   28c13:	f2 0f 59 d2          	mulsd  %xmm2,%xmm2
   28c17:	f2 0f 58 d7          	addsd  %xmm7,%xmm2
   28c1b:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   28c20:	f2 41 0f 59 f8       	mulsd  %xmm8,%xmm7
   28c25:	f2 0f 58 d7          	addsd  %xmm7,%xmm2
   28c29:	f2 0f 10 78 18       	movsd  0x18(%rax),%xmm7
   28c2e:	f2 41 0f 58 d1       	addsd  %xmm9,%xmm2
   28c33:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   28c38:	f2 45 0f 51 db       	sqrtsd %xmm11,%xmm11
   28c3d:	f2 44 0f 59 da       	mulsd  %xmm2,%xmm11
   28c42:	f2 41 0f 5e fb       	divsd  %xmm11,%xmm7
   28c47:	66 0f 28 d7          	movapd %xmm7,%xmm2
   28c4b:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   28c4f:	66 41 0f 59 fa       	mulpd  %xmm10,%xmm7
   28c54:	f2 41 0f 59 d0       	mulsd  %xmm8,%xmm2
   28c59:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   28c5d:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   28c61:	49 8d 45 01          	lea    0x1(%r13),%rax
   28c65:	48 39 d8             	cmp    %rbx,%rax
   28c68:	0f 83 bf 01 00 00    	jae    28e2d <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x49d>
   28c6e:	49 89 dc             	mov    %rbx,%r12
   28c71:	4d 29 ec             	sub    %r13,%r12
   28c74:	4d 8d 74 24 ff       	lea    -0x1(%r12),%r14
   28c79:	49 83 fc 02          	cmp    $0x2,%r12
   28c7d:	0f 84 29 01 00 00    	je     28dac <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x41c>
   28c83:	49 89 c4             	mov    %rax,%r12
   28c86:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   28c8b:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   28c90:	4d 89 f5             	mov    %r14,%r13
   28c93:	49 c1 e4 05          	shl    $0x5,%r12
   28c97:	49 d1 ed             	shr    $1,%r13
   28c9a:	66 44 0f 28 d4       	movapd %xmm4,%xmm10
   28c9f:	66 44 0f 14 e3       	unpcklpd %xmm3,%xmm12
   28ca4:	49 01 fc             	add    %rdi,%r12
   28ca7:	49 c1 e5 06          	shl    $0x6,%r13
   28cab:	66 44 0f 15 db       	unpckhpd %xmm3,%xmm11
   28cb0:	66 45 0f 14 d2       	unpcklpd %xmm10,%xmm10
   28cb5:	4d 01 e5             	add    %r12,%r13
   28cb8:	66 45 0f 10 2c 24    	movupd (%r12),%xmm13
   28cbe:	66 45 0f 10 74 24 20 	movupd 0x20(%r12),%xmm14
   28cc5:	49 83 c4 40          	add    $0x40,%r12
   28cc9:	66 41 0f 10 54 24 d0 	movupd -0x30(%r12),%xmm2
   28cd0:	66 45 0f 10 7c 24 f0 	movupd -0x10(%r12),%xmm15
   28cd7:	66 45 0f 16 6c 24 d0 	movhpd -0x30(%r12),%xmm13
   28cde:	66 45 0f 12 7c 24 e8 	movlpd -0x18(%r12),%xmm15
   28ce5:	66 41 0f 12 54 24 c8 	movlpd -0x38(%r12),%xmm2
   28cec:	66 45 0f 16 74 24 f0 	movhpd -0x10(%r12),%xmm14
   28cf3:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   28cf8:	66 45 0f 15 ee       	unpckhpd %xmm14,%xmm13
   28cfd:	66 0f 28 fa          	movapd %xmm2,%xmm7
   28d01:	66 45 0f 14 c6       	unpcklpd %xmm14,%xmm8
   28d06:	66 41 0f 14 d7       	unpcklpd %xmm15,%xmm2
   28d0b:	66 45 0f 5c c4       	subpd  %xmm12,%xmm8
   28d10:	66 41 0f 5c d3       	subpd  %xmm11,%xmm2
   28d15:	66 41 0f 15 ff       	unpckhpd %xmm15,%xmm7
   28d1a:	66 45 0f 5c ea       	subpd  %xmm10,%xmm13
   28d1f:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   28d24:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   28d29:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
   28d2e:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   28d33:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   28d38:	66 45 0f 28 fd       	movapd %xmm13,%xmm15
   28d3d:	66 45 0f 59 fd       	mulpd  %xmm13,%xmm15
   28d42:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   28d47:	66 44 0f 58 35 20 86 	addpd  0x68620(%rip),%xmm14        # 91370 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x18>
   28d4e:	06 00 
   28d50:	66 45 0f 51 fe       	sqrtpd %xmm14,%xmm15
   28d55:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   28d5a:	66 41 0f 5e fe       	divpd  %xmm14,%xmm7
   28d5f:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   28d64:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   28d68:	66 41 0f 59 fd       	mulpd  %xmm13,%xmm7
   28d6d:	66 45 0f 28 f0       	movapd %xmm8,%xmm14
   28d72:	66 44 0f 14 f2       	unpcklpd %xmm2,%xmm14
   28d77:	66 44 0f 15 c2       	unpckhpd %xmm2,%xmm8
   28d7c:	f2 0f 58 cf          	addsd  %xmm7,%xmm1
   28d80:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   28d85:	66 0f 15 ff          	unpckhpd %xmm7,%xmm7
   28d89:	66 41 0f 58 c0       	addpd  %xmm8,%xmm0
   28d8e:	f2 0f 58 cf          	addsd  %xmm7,%xmm1
   28d92:	4d 39 e5             	cmp    %r12,%r13
   28d95:	0f 85 1d ff ff ff    	jne    28cb8 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x328>
   28d9b:	41 f6 c6 01          	test   $0x1,%r14b
   28d9f:	0f 84 88 00 00 00    	je     28e2d <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x49d>
   28da5:	49 83 e6 fe          	and    $0xfffffffffffffffe,%r14
   28da9:	4c 01 f0             	add    %r14,%rax
   28dac:	48 c1 e0 05          	shl    $0x5,%rax
   28db0:	48 01 f8             	add    %rdi,%rax
   28db3:	66 44 0f 10 10       	movupd (%rax),%xmm10
   28db8:	f2 44 0f 10 40 10    	movsd  0x10(%rax),%xmm8
   28dbe:	66 44 0f 5c d3       	subpd  %xmm3,%xmm10
   28dc3:	f2 44 0f 5c c4       	subsd  %xmm4,%xmm8
   28dc8:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   28dcd:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   28dd2:	f2 41 0f 59 fa       	mulsd  %xmm10,%xmm7
   28dd7:	66 0f 15 d2          	unpckhpd %xmm2,%xmm2
   28ddb:	f2 0f 59 d2          	mulsd  %xmm2,%xmm2
   28ddf:	f2 0f 58 d7          	addsd  %xmm7,%xmm2
   28de3:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   28de8:	f2 41 0f 59 f8       	mulsd  %xmm8,%xmm7
   28ded:	f2 0f 58 d7          	addsd  %xmm7,%xmm2
   28df1:	f2 0f 10 78 18       	movsd  0x18(%rax),%xmm7
   28df6:	f2 41 0f 58 d1       	addsd  %xmm9,%xmm2
   28dfb:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   28e00:	f2 45 0f 51 db       	sqrtsd %xmm11,%xmm11
   28e05:	f2 44 0f 59 da       	mulsd  %xmm2,%xmm11
   28e0a:	66 0f 28 d7          	movapd %xmm7,%xmm2
   28e0e:	f2 41 0f 5e d3       	divsd  %xmm11,%xmm2
   28e13:	66 0f 28 fa          	movapd %xmm2,%xmm7
   28e17:	f2 41 0f 59 d0       	mulsd  %xmm8,%xmm2
   28e1c:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   28e20:	66 41 0f 59 fa       	mulpd  %xmm10,%xmm7
   28e25:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   28e29:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   28e2d:	66 0f 59 05 4b 85 06 	mulpd  0x6854b(%rip),%xmm0        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   28e34:	00 
   28e35:	49 83 c2 08          	add    $0x8,%r10
   28e39:	48 83 c6 18          	add    $0x18,%rsi
   28e3d:	48 83 c1 18          	add    $0x18,%rcx
   28e41:	66 0f 28 15 37 85 06 	movapd 0x68537(%rip),%xmm2        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   28e48:	00 
   28e49:	f2 0f 59 0d 2f 85 06 	mulsd  0x6852f(%rip),%xmm1        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   28e50:	00 
   28e51:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   28e55:	f2 0f 58 cd          	addsd  %xmm5,%xmm1
   28e59:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   28e5d:	0f 11 44 24 d0       	movups %xmm0,-0x30(%rsp)
   28e62:	f2 0f 11 4c 24 e0    	movsd  %xmm1,-0x20(%rsp)
   28e68:	66 0f 58 d3          	addpd  %xmm3,%xmm2
   28e6c:	f2 0f 10 1d 0c 85 06 	movsd  0x6850c(%rip),%xmm3        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   28e73:	00 
   28e74:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   28e78:	0f 11 56 e8          	movups %xmm2,-0x18(%rsi)
   28e7c:	0f 29 54 24 b8       	movaps %xmm2,-0x48(%rsp)
   28e81:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
   28e85:	f2 0f 11 5c 24 c8    	movsd  %xmm3,-0x38(%rsp)
   28e8b:	48 8b 44 24 c8       	mov    -0x38(%rsp),%rax
   28e90:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
   28e94:	48 8b 44 24 e0       	mov    -0x20(%rsp),%rax
   28e99:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
   28e9d:	48 89 41 f8          	mov    %rax,-0x8(%rcx)
   28ea1:	4d 39 d7             	cmp    %r10,%r15
   28ea4:	0f 85 ee fb ff ff    	jne    28a98 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x108>
   28eaa:	4c 8b 74 24 88       	mov    -0x78(%rsp),%r14
   28eaf:	4c 8b 6c 24 90       	mov    -0x70(%rsp),%r13
   28eb4:	4c 8b 64 24 98       	mov    -0x68(%rsp),%r12
   28eb9:	49 83 c5 01          	add    $0x1,%r13
   28ebd:	48 83 ed 40          	sub    $0x40,%rbp
   28ec1:	49 81 c6 00 02 00 00 	add    $0x200,%r14
   28ec8:	49 81 c4 00 06 00 00 	add    $0x600,%r12
   28ecf:	4d 39 dd             	cmp    %r11,%r13
   28ed2:	0f 85 58 fb ff ff    	jne    28a30 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xa0>
   28ed8:	5b                   	pop    %rbx
   28ed9:	5d                   	pop    %rbp
   28eda:	41 5c                	pop    %r12
   28edc:	41 5d                	pop    %r13
   28ede:	41 5e                	pop    %r14
   28ee0:	41 5f                	pop    %r15
   28ee2:	c3                   	ret
   28ee3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28ee8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   28eec:	66 0f ef c9          	pxor   %xmm1,%xmm1
   28ef0:	e9 6c fd ff ff       	jmp    28c61 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2d1>
   28ef5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   28ef9:	66 0f ef c9          	pxor   %xmm1,%xmm1
   28efd:	31 c0                	xor    %eax,%eax
   28eff:	e9 dc fc ff ff       	jmp    28be0 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x250>
   28f04:	48 01 f0             	add    %rsi,%rax
   28f07:	4d 85 d2             	test   %r10,%r10
   28f0a:	0f 85 b5 fa ff ff    	jne    289c5 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<true>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x35>
   28f10:	c3                   	ret
   28f11:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   28f18:	00 00 00 
   28f1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

