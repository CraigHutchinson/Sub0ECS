0000000000028170 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)>:
   28170:	f3 0f 1e fa          	endbr64
   28174:	41 57                	push   %r15
   28176:	41 56                	push   %r14
   28178:	41 55                	push   %r13
   2817a:	41 54                	push   %r12
   2817c:	55                   	push   %rbp
   2817d:	53                   	push   %rbx
   2817e:	48 8b 17             	mov    (%rdi),%rdx
   28181:	8b 47 08             	mov    0x8(%rdi),%eax
   28184:	48 8b 4a 18          	mov    0x18(%rdx),%rcx
   28188:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
   2818c:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
   28191:	48 0f af f8          	imul   %rax,%rdi
   28195:	48 39 c1             	cmp    %rax,%rcx
   28198:	0f 82 c0 02 00 00    	jb     2845e <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2ee>
   2819e:	48 01 c7             	add    %rax,%rdi
   281a1:	48 39 c8             	cmp    %rcx,%rax
   281a4:	48 83 54 24 a0 00    	adcq   $0x0,-0x60(%rsp)
   281aa:	48 83 7c 24 a0 00    	cmpq   $0x0,-0x60(%rsp)
   281b0:	0f 84 73 02 00 00    	je     28429 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2b9>
   281b6:	4c 8b 32             	mov    (%rdx),%r14
   281b9:	48 89 fa             	mov    %rdi,%rdx
   281bc:	f2 0f 10 25 bc 91 06 	movsd  0x691bc(%rip),%xmm4        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   281c3:	00 
   281c4:	45 31 ed             	xor    %r13d,%r13d
   281c7:	48 c1 e2 06          	shl    $0x6,%rdx
   281cb:	f2 0f 10 1d ad 91 06 	movsd  0x691ad(%rip),%xmm3        # 91380 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x28>
   281d2:	00 
   281d3:	4c 89 e9             	mov    %r13,%rcx
   281d6:	f2 0f 10 35 92 91 06 	movsd  0x69192(%rip),%xmm6        # 91370 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x18>
   281dd:	00 
   281de:	49 8b 06             	mov    (%r14),%rax
   281e1:	f2 0f 10 2d c7 93 06 	movsd  0x693c7(%rip),%xmm5        # 915b0 <std::_Sp_make_shared_tag::_S_ti()::__tag+0x258>
   281e8:	00 
   281e9:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   281ed:	4c 89 f6             	mov    %r14,%rsi
   281f0:	4c 8b 38             	mov    (%rax),%r15
   281f3:	49 8b 46 10          	mov    0x10(%r14),%rax
   281f7:	48 8b 58 18          	mov    0x18(%rax),%rbx
   281fb:	4c 8b 58 10          	mov    0x10(%rax),%r11
   281ff:	4c 89 7c 24 a8       	mov    %r15,-0x58(%rsp)
   28204:	48 8b 00             	mov    (%rax),%rax
   28207:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
   2820c:	49 8b 46 08          	mov    0x8(%r14),%rax
   28210:	48 8b 00             	mov    (%rax),%rax
   28213:	48 29 d0             	sub    %rdx,%rax
   28216:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
   2821a:	48 c1 e7 09          	shl    $0x9,%rdi
   2821e:	48 c1 e2 09          	shl    $0x9,%rdx
   28222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   28228:	4c 8b 7c 24 a8       	mov    -0x58(%rsp),%r15
   2822d:	49 39 c7             	cmp    %rax,%r15
   28230:	4d 89 f8             	mov    %r15,%r8
   28233:	4c 0f 47 c0          	cmova  %rax,%r8
   28237:	4d 85 c0             	test   %r8,%r8
   2823a:	0f 84 c5 01 00 00    	je     28405 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x295>
   28240:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
   28244:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
   28249:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
   2824d:	49 ba b7 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r10
   28254:	db b6 6d 
   28257:	48 89 4c 24 98       	mov    %rcx,-0x68(%rsp)
   2825c:	4e 8d 3c c2          	lea    (%rdx,%r8,8),%r15
   28260:	4d 8b 09             	mov    (%r9),%r9
   28263:	4d 8b b1 70 15 00 00 	mov    0x1570(%r9),%r14
   2826a:	4d 8b a1 68 15 00 00 	mov    0x1568(%r9),%r12
   28271:	49 89 d1             	mov    %rdx,%r9
   28274:	4d 89 f5             	mov    %r14,%r13
   28277:	4d 29 e5             	sub    %r12,%r13
   2827a:	49 c1 fd 03          	sar    $0x3,%r13
   2827e:	4d 0f af ea          	imul   %r10,%r13
   28282:	4c 8b 54 24 b0       	mov    -0x50(%rsp),%r10
   28287:	49 8d 2c 3a          	lea    (%r10,%rdi,1),%rbp
   2828b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   28290:	4c 8b 55 00          	mov    0x0(%rbp),%r10
   28294:	4a 8d 0c d5 00 00 00 	lea    0x0(,%r10,8),%rcx
   2829b:	00 
   2829c:	4c 29 d1             	sub    %r10,%rcx
   2829f:	49 8d 34 cc          	lea    (%r12,%rcx,8),%rsi
   282a3:	f3 0f 6f 3e          	movdqu (%rsi),%xmm7
   282a7:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
   282ac:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
   282b0:	0f 29 7c 24 b8       	movaps %xmm7,-0x48(%rsp)
   282b5:	f3 0f 6f 7e 10       	movdqu 0x10(%rsi),%xmm7
   282ba:	48 89 4c 24 e8       	mov    %rcx,-0x18(%rsp)
   282bf:	0f 29 7c 24 c8       	movaps %xmm7,-0x38(%rsp)
   282c4:	0f 29 4c 24 d8       	movaps %xmm1,-0x28(%rsp)
   282c9:	4d 39 f4             	cmp    %r14,%r12
   282cc:	0f 84 7e 01 00 00    	je     28450 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2e0>
   282d2:	4c 89 e1             	mov    %r12,%rcx
   282d5:	66 45 0f ef c9       	pxor   %xmm9,%xmm9
   282da:	66 0f ef c9          	pxor   %xmm1,%xmm1
   282de:	45 31 c0             	xor    %r8d,%r8d
   282e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   282e8:	4d 39 d0             	cmp    %r10,%r8
   282eb:	0f 84 47 01 00 00    	je     28438 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x2c8>
   282f1:	66 0f 10 39          	movupd (%rcx),%xmm7
   282f5:	66 0f 10 16          	movupd (%rsi),%xmm2
   282f9:	49 83 c0 01          	add    $0x1,%r8
   282fd:	48 83 c1 38          	add    $0x38,%rcx
   28301:	66 0f 5c fa          	subpd  %xmm2,%xmm7
   28305:	66 0f 28 d7          	movapd %xmm7,%xmm2
   28309:	66 0f 28 c7          	movapd %xmm7,%xmm0
   2830d:	f2 0f 59 c7          	mulsd  %xmm7,%xmm0
   28311:	66 0f 15 d2          	unpckhpd %xmm2,%xmm2
   28315:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   2831a:	f2 0f 10 51 d8       	movsd  -0x28(%rcx),%xmm2
   2831f:	f2 0f 5c 56 10       	subsd  0x10(%rsi),%xmm2
   28324:	f2 45 0f 59 c0       	mulsd  %xmm8,%xmm8
   28329:	f2 41 0f 58 c0       	addsd  %xmm8,%xmm0
   2832e:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   28333:	f2 44 0f 59 c2       	mulsd  %xmm2,%xmm8
   28338:	f2 41 0f 58 c0       	addsd  %xmm8,%xmm0
   2833d:	f2 44 0f 10 41 f8    	movsd  -0x8(%rcx),%xmm8
   28343:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   28348:	f2 0f 58 c6          	addsd  %xmm6,%xmm0
   2834c:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   28351:	f2 45 0f 51 d2       	sqrtsd %xmm10,%xmm10
   28356:	f2 41 0f 59 c2       	mulsd  %xmm10,%xmm0
   2835b:	f2 44 0f 5e c0       	divsd  %xmm0,%xmm8
   28360:	f2 41 0f 59 d0       	mulsd  %xmm8,%xmm2
   28365:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   2836a:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   2836e:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   28372:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   28376:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   2837b:	4d 39 e8             	cmp    %r13,%r8
   2837e:	0f 82 64 ff ff ff    	jb     282e8 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
   28384:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   28389:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
   2838d:	f2 0f 58 4c 24 e0    	addsd  -0x20(%rsp),%xmm1
   28393:	66 0f 10 44 24 d0    	movupd -0x30(%rsp),%xmm0
   28399:	48 83 c5 08          	add    $0x8,%rbp
   2839d:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   283a2:	f2 0f 11 4c 24 e0    	movsd  %xmm1,-0x20(%rsp)
   283a8:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
   283ac:	f2 0f 58 4c 24 c8    	addsd  -0x38(%rsp),%xmm1
   283b2:	66 0f 28 d0          	movapd %xmm0,%xmm2
   283b6:	0f 11 44 24 d0       	movups %xmm0,-0x30(%rsp)
   283bb:	66 0f 59 d4          	mulpd  %xmm4,%xmm2
   283bf:	f2 0f 11 4c 24 c8    	movsd  %xmm1,-0x38(%rsp)
   283c5:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
   283ca:	66 0f 58 54 24 b8    	addpd  -0x48(%rsp),%xmm2
   283d0:	4a 89 4c 0b 10       	mov    %rcx,0x10(%rbx,%r9,1)
   283d5:	48 8b 4c 24 e0       	mov    -0x20(%rsp),%rcx
   283da:	42 0f 11 14 0b       	movups %xmm2,(%rbx,%r9,1)
   283df:	4b 89 4c 0b 10       	mov    %rcx,0x10(%r11,%r9,1)
   283e4:	43 0f 11 04 0b       	movups %xmm0,(%r11,%r9,1)
   283e9:	49 83 c1 18          	add    $0x18,%r9
   283ed:	0f 29 54 24 b8       	movaps %xmm2,-0x48(%rsp)
   283f2:	4d 39 cf             	cmp    %r9,%r15
   283f5:	0f 85 95 fe ff ff    	jne    28290 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x120>
   283fb:	48 8b 74 24 90       	mov    -0x70(%rsp),%rsi
   28400:	48 8b 4c 24 98       	mov    -0x68(%rsp),%rcx
   28405:	4c 8b 74 24 a0       	mov    -0x60(%rsp),%r14
   2840a:	48 83 c1 01          	add    $0x1,%rcx
   2840e:	48 83 e8 40          	sub    $0x40,%rax
   28412:	48 81 c2 00 06 00 00 	add    $0x600,%rdx
   28419:	48 81 c7 00 02 00 00 	add    $0x200,%rdi
   28420:	4c 39 f1             	cmp    %r14,%rcx
   28423:	0f 85 ff fd ff ff    	jne    28228 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0xb8>
   28429:	5b                   	pop    %rbx
   2842a:	5d                   	pop    %rbp
   2842b:	41 5c                	pop    %r12
   2842d:	41 5d                	pop    %r13
   2842f:	41 5e                	pop    %r14
   28431:	41 5f                	pop    %r15
   28433:	c3                   	ret
   28434:	0f 1f 40 00          	nopl   0x0(%rax)
   28438:	49 83 c0 01          	add    $0x1,%r8
   2843c:	48 83 c1 38          	add    $0x38,%rcx
   28440:	4d 39 e8             	cmp    %r13,%r8
   28443:	0f 82 9f fe ff ff    	jb     282e8 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x178>
   28449:	e9 36 ff ff ff       	jmp    28384 <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x214>
   2844e:	66 90                	xchg   %ax,%ax
   28450:	66 45 0f ef c9       	pxor   %xmm9,%xmm9
   28455:	66 0f ef c9          	pxor   %xmm1,%xmm1
   28459:	e9 2f ff ff ff       	jmp    2838d <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x21d>
   2845e:	48 01 cf             	add    %rcx,%rdi
   28461:	e9 44 fd ff ff       	jmp    281aa <std::_Function_handler<void (), sub0ecs::adapters::PipelinePool::parallelFor<sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}>(unsigned long, sub0ecs::store::BasicWorld<true, std::tuple<sub0ecs::Query<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id> >, sub0ecs::store::Volatile<> >::eachParallel<bench::nbody::Position, bench::nbody::Velocity, bench::nbody::Mass, bench::nbody::Id, sub0ecs::adapters::PipelinePool, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}, 64ul>(sub0ecs::adapters::PipelinePool&, bench::nbody::BasicEcs<false>::tick<64ul, sub0ecs::adapters::PipelinePool>(sub0ecs::adapters::PipelinePool&)::{lambda(unsigned int, bench::nbody::Position&, bench::nbody::Velocity&, bench::nbody::Mass const&, bench::nbody::Id const&)#1}&&, sub0ecs::store::RowGrain<64ul>)::{lambda(unsigned long, unsigned int)#1}&)::{lambda()#1}>::_M_invoke(std::_Any_data const&)+0x3a>
   28466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2846d:	00 00 00 

